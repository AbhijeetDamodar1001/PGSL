#include "kmeans.h"
#include <cmath>
#include <limits>

static double dist2(const vector<double>& a, const vector<double>& b)
{
    double s = 0;
    for (int i = 0; i < (int)a.size(); i++)
    {
        double x = a[i] - b[i];
        s += x * x;
    }
    return s;
}

KMeansResult runKMeans(const vector<vector<double>>& points,
                       int k, int maxIter, double tol)
{
    int n = (int)points.size();
    int d = (int)points[0].size();

    vector<vector<double>> center(k, vector<double>(d));
    for (int i = 0; i < k; i++)
        center[i] = points[i];

    vector<int> group(n, 0);
    bool done = false;
    int it = 0;

    while (it < maxIter && !done)
    {
        it++;
        done = true;

        for (int i = 0; i < n; i++)
        {
            int best = 0;
            double bestDist = dist2(points[i], center[0]);

            for (int c = 1; c < k; c++)
            {
                double x = dist2(points[i], center[c]);
                if (x < bestDist)
                {
                    bestDist = x;
                    best = c;
                }
            }

            if (group[i] != best)
                done = false;

            group[i] = best;
        }

        vector<vector<double>> sum(k, vector<double>(d, 0));
        vector<int> cnt(k, 0);

        for (int i = 0; i < n; i++)
        {
            cnt[group[i]]++;
            for (int j = 0; j < d; j++)
                sum[group[i]][j] += points[i][j];
        }

        double shift = 0;

        for (int c = 0; c < k; c++)
        {
            if (cnt[c] == 0)
                continue;

            vector<double> next = center[c];
            for (int j = 0; j < d; j++)
                next[j] = sum[c][j] / cnt[c];

            shift = max(shift, sqrt(dist2(center[c], next)));
            center[c] = next;
        }

        if (shift <= tol)
            done = true;
    }

    double wcss = 0;
    for (int i = 0; i < n; i++)
        wcss += dist2(points[i], center[group[i]]);

    KMeansResult ans;
    ans.group = group;
    ans.center = center;
    ans.iterations = it;
    ans.wcss = wcss;
    ans.converged = done;
    return ans;
}
