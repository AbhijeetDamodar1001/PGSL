#include "fastmap.h"
#include <cmath>

static int farthest(const vector<double>& row)
{
    int p = 0;
    for (int i = 1; i < (int)row.size(); i++)
        if (row[i] > row[p])
            p = i;
    return p;
}

FastMapResult runFastMap(vector<vector<double>> dist, int k)
{
    int n = (int)dist.size();
    vector<vector<double>> coord(n, vector<double>(k, 0));
    vector<pair<int,int>> pivots;

    for (int dim = 0; dim < k; dim++)
    {
        int a = farthest(dist[0]);
        int b = farthest(dist[a]);
        double ab = dist[a][b];

        pivots.push_back({a, b});

        if (ab <= 0)
            break;

        for (int i = 0; i < n; i++)
        {
            double x = (dist[a][i] * dist[a][i]
                      + ab * ab
                      - dist[b][i] * dist[b][i]) / (2 * ab);

            coord[i][dim] = x;
        }

        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                double old = dist[i][j];
                double x = coord[i][dim] - coord[j][dim];
                double val = old * old - x * x;

                if (val < 0 && val > -1e-9)
                    val = 0;

                if (val < 0)
                    val = 0;

                dist[i][j] = sqrt(val);
                dist[j][i] = dist[i][j];
            }
        }
    }

    FastMapResult ans;
    ans.coord = coord;
    ans.pivots = pivots;
    return ans;
}
