#ifndef FASTMAP_H
#define FASTMAP_H

#include <vector>
using namespace std;

struct FastMapResult
{
    vector<vector<double>> coord;
    vector<pair<int,int>> pivots;
};

FastMapResult runFastMap(vector<vector<double>> dist, int k);

#endif
