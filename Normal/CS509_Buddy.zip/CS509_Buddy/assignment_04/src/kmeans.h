#ifndef KMEANS_H
#define KMEANS_H

#include <vector>
using namespace std;

struct KMeansResult
{
    vector<int> group;
    vector<vector<double>> center;
    int iterations;
    double wcss;
    bool converged;
};

KMeansResult runKMeans(const vector<vector<double>>& points,
                       int k, int maxIter, double tol);

#endif
