CS509 - Assignment 4
Buddy Task: K-Means Clustering and FastMap

Members
1. Abhijeet Damodar - 2026AIM1001
2. Chiranton Baruah - 2026CSM1009

This part of the assignment contains K-Means Clustering and FastMap.

Folder structure

assignment_04_buddy/
|
|-- driver/
|   |-- driver.cpp
|
|-- src/
|   |-- kmeans.cpp
|   |-- kmeans.h
|   |-- fastmap.cpp
|   |-- fastmap.h
|
|-- tests/
|   |-- km_01.txt
|   |-- km_02.txt
|   |-- km_03.txt
|   |-- km_04.txt
|   |-- fm_01.txt
|   |-- fm_02.txt
|   |-- fm_03.txt
|   `-- make_fm_04.py
|
|-- Makefile
`-- README.txt

K-Means

K-Means divides the points into K groups. The first K points are used as
the starting centroids. Each point is assigned to the nearest centroid,
then the centroids are updated. This is repeated until the centroids stop
moving enough or the maximum iteration count is reached.

The program prints:
- cluster assignment of each point
- final centroids
- WCSS
- number of iterations
- convergence status
- execution time

Required K-Means tests

km_01: N=100, D=2, K=3
km_02: N=1000, D=2, K=5
km_03: N=10000, D=5, K=8
km_04: N=100000, D=5, K=10

FastMap

FastMap converts objects represented by pairwise distances into a smaller
k-dimensional representation. For each dimension, two far apart pivot
objects are selected. The objects are projected using the distance formula
and the remaining distances are reduced before the next dimension.

The program prints:
- target dimensions
- pivot pair for every dimension
- coordinates of every object
- execution time

Required FastMap tests

fm_01: N=10, K=2
fm_02: N=100, K=2
fm_03: N=1000, K=3
fm_04: N=10000, K=3

The first three FastMap files are included directly. fm_04 is very large
because the assignment requires a full 10000 x 10000 distance matrix.
The file can be generated inside the tests folder using:

python make_fm_04.py

The generator uses d(i,j)=|i-j|, which is symmetric, has zero diagonal,
is non-negative and satisfies the triangle inequality.

Compilation

g++ -std=c++17 driver/driver.cpp src/kmeans.cpp src/fastmap.cpp -o assignment4_buddy.exe

Running

K-Means:
.\assignment4_buddy.exe kmeans tests\km_01.txt

FastMap:
.\assignment4_buddy.exe fastmap tests\fm_01.txt

Complexity

K-Means is roughly O(N * K * D * I), where I is the number of iterations.

FastMap works on a full distance matrix and takes roughly O(K * N^2)
time, with O(N^2) distance storage.

Timing

The timer starts immediately before the algorithm function is called.
File reading and output printing are outside the measured algorithm time.
