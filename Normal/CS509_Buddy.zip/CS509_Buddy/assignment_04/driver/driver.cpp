#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <chrono>
#include <iomanip>
#include "../src/kmeans.h"
#include "../src/fastmap.h"

using namespace std;

void runKMeansFile(const string& file)
{
    ifstream in(file);
    if (!in)
    {
        cout << "Could not open file.\n";
        return;
    }

    int n, d, k;
    in >> n >> d >> k;

    vector<vector<double>> points(n, vector<double>(d));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < d; j++)
            in >> points[i][j];

    string word;
    int maxIter;
    double tol;
    in >> word >> maxIter;
    in >> word >> tol;

    auto start = chrono::high_resolution_clock::now();
    KMeansResult ans = runKMeans(points, k, maxIter, tol);
    auto stop = chrono::high_resolution_clock::now();

    double time = chrono::duration<double, milli>(stop - start).count();

    cout << "\nAlgorithm: K-Means Clustering\n";
    cout << "K: " << k << "\n";
    cout << "Point assignments:\n";
    for (int i = 0; i < n; i++)
        cout << i << " " << ans.group[i] << "\n";

    cout << "Final centroids:\n";
    cout << fixed << setprecision(6);
    for (int c = 0; c < k; c++)
    {
        cout << c << ":";
        for (int j = 0; j < d; j++)
            cout << " " << ans.center[c][j];
        cout << "\n";
    }

    cout << "WCSS: " << ans.wcss << "\n";
    cout << "Iterations: " << ans.iterations << "\n";
    cout << "Converged: " << (ans.converged ? "true" : "false") << "\n";
    cout << "Execution time: " << time << " ms\n";
}

void runFastMapFile(const string& file)
{
    ifstream in(file);
    if (!in)
    {
        cout << "Could not open file.\n";
        return;
    }

    int n, k;
    in >> n >> k;

    vector<vector<double>> dist(n, vector<double>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            in >> dist[i][j];

    auto start = chrono::high_resolution_clock::now();
    FastMapResult ans = runFastMap(dist, k);
    auto stop = chrono::high_resolution_clock::now();

    double time = chrono::duration<double, milli>(stop - start).count();

    cout << "\nAlgorithm: FastMap\n";
    cout << "Target dimensions: " << k << "\n";
    cout << "Pivots per dimension:\n";
    for (int i = 0; i < (int)ans.pivots.size(); i++)
        cout << "Dim " << i + 1 << ": "
             << ans.pivots[i].first << " "
             << ans.pivots[i].second << "\n";

    cout << "Object coordinates:\n";
    cout << fixed << setprecision(6);
    for (int i = 0; i < n; i++)
    {
        cout << i << ":";
        for (int j = 0; j < k; j++)
            cout << " " << ans.coord[i][j];
        cout << "\n";
    }

    cout << "Execution time: " << time << " ms\n";
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cout << "Usage: assignment4_buddy.exe kmeans/fastmap testfile\n";
        return 0;
    }

    string type = argv[1];
    string file = argv[2];

    if (type == "kmeans")
        runKMeansFile(file);
    else if (type == "fastmap")
        runFastMapFile(file);
    else
        cout << "Use kmeans or fastmap.\n";

    return 0;
}
