# Generates the required FastMap 10,000 object test.
# The matrix is d(i,j) = |i-j|, which is a valid distance matrix.

n = 10000
k = 3

with open("fm_04.txt", "w") as f:
    f.write(f"{n} {k}\n")
    for i in range(n):
        f.write(" ".join(str(abs(i-j)) for j in range(n)) + "\n")

print("fm_04.txt created")
