#include<iostream>
#include<fstream>
#include<vector>

#include "../src/csr.h"
#include "../src/bfs.h"

using namespace std;

int main()
{
    ifstream fin("tests/test_02.txt");

    if(fin.fail())
    {
        cout<<"File not found";
        return 0;
    }

    int vertices, edges;
    fin >> vertices >> edges;

    vector<vector<int>> graph(vertices);

    for(int i=0; i<edges; i++)
    {
        int u,v;
        fin>>u>>v;

        graph[u].push_back(v);
    }

    vector<int> offset;
    vector<int> edgeArray;

    convertToCSR(graph, offset, edgeArray);

    cout<<"BFS Traversal : ";

    BFS(offset, edgeArray, 0);

    fin.close();

    return 0;
}