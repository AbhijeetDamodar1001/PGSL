#ifndef BFS_H
#define BFS_H

#include <vector>

using namespace std;

void BFS(
    const vector<int>& offset,
    const vector<int>& edges,
    int source
);

#endif