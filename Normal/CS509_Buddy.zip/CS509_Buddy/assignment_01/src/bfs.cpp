#include "bfs.h"
#include<iostream>
#include<queue>

using namespace std;

void BFS(
    const vector<int>& offset,
    const vector<int>& edges,
    int source)
{
    vector<bool> visited(offset.size()-1,false);

    queue<int> q;

    visited[source] = true;

    q.push(source);

    while(!q.empty())
    {
        int curr = q.front();
        q.pop();

        cout<<curr<<" ";

        for(int i=offset[curr]; i<offset[curr+1]; i++)
        {
            int next = edges[i];

            if(visited[next]==false)
            {
                visited[next]=true;
                q.push(next);
            }
        }
    }

    cout<<endl;
}