#include "csr.h"

void convertToCSR(
    const vector<vector<int>>& graph,
    vector<int>& offset,
    vector<int>& edges)
{
    offset.clear(); // Purana data hata diya.
    edges.clear();  //Purana edge hata diya.

    int count = 0;

    offset.push_back(0);  // CSR ka pehla offset hamesha 0 hota hai

    for(int i = 0; i < graph.size(); i++)
    {
        count = count + graph[i].size();
        offset.push_back(count);

        for(int j = 0; j < graph[i].size(); j++)
        {
            edges.push_back(graph[i][j]);
        }
    }
}