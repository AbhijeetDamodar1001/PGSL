#ifndef CSR_H
#define CSR_H

#include <iostream>
#include <vector>

using namespace std;

void convertToCSR(
    const vector<vector<int>>& graph, /*Graph read-only hai.
                                        CSR banate waqt graph change nahi karna.
                                        Isliye const.*/
    vector<int>& offset,
    vector<int>& edges
);

#endif