# Assignment 4 — K-Means Clustering + FastMap (Poora Samjho — Hinglish Guide)

Chhota (319 lines) lekin conceptually IMPORTANT assignment hai — 2 CLASSIC
**Data Mining / Machine Learning** algorithms implement karte hai:
1. **K-Means Clustering** — points ko K groups mein baantna
2. **FastMap** — sirf "pairwise distances" se objects ko chhoti dimensional space mein "place" karna

Maine dono algorithms **khud compile aur RUN karke** verify kiye hai (sirf
theory nahi, ASLI numbers). Har `.cpp`/`.h` file ke andar poora HAND-TRACED
dry-run milega jo maine COMPILE karke bhi CONFIRM kiya.

---

## 1. Padhne Ka SAHI ORDER

```
1. src/kmeans.h    -> Pehle samjho KMeansResult struct mein kya-kya store hota hai
2. src/kmeans.cpp   -> Phir ASLI K-Means algorithm (dist2 -> assign -> update loop)
3. src/fastmap.h    -> FastMapResult struct samjho
4. src/fastmap.cpp  -> FastMap algorithm (farthest() -> pivot-selection -> projection -> distance-update)
5. driver/driver.cpp -> SABSE AAKHIR mein — dekho file kaise padhi jaati hai
                        aur dono algorithms kaise "wire up" hote hai
```

**WHY is order?** K-Means SIMPLER hai (concept sirf "nearest centroid dhoondo,
average nikaalo, repeat karo") — pehle isse samjho taaki "iterative
refinement" ka pattern clear ho jaaye. FastMap thoda ABSTRACT hai (cosine-law
formula involve karta hai), isliye usko doosra rakha.

---

## 2. K-MEANS — Concept + Verified Dry Run

### Idea (1 line mein)
"K centroids se shuru karo -> har point ko NEAREST centroid do -> centroids
ko apne group ke AVERAGE par move karo -> jab tak STABLE na ho jaaye, repeat."

### Vectors kyu banaye gaye (important!)
| Variable | Type | Kyu aisa? |
|---|---|---|
| `points` | `vector<vector<double>>` | N points, har point D-dimensional — isliye "outer vector = kitne points, inner vector = har point ke coordinates" |
| `center` | `vector<vector<double>>` | K centroids, har centroid khud ek D-dimensional point hai (SAME shape jaisa ek point) |
| `group` | `vector<int>` | har point ko sirf EK cluster-number (int) chahiye, isliye simple 1D vector |
| `sum`, `cnt` | `vector<vector<double>>`, `vector<int>` | naye centroid ka AVERAGE nikaalne ke liye "total" aur "count" alag track karna padta hai |

### Verified Dry Run (6 custom points, K=2 — maine khud haath se trace karke COMPILE karke bhi confirm kiya)
```
Points: (0,0) (10,10) (0,1) (10,11) (1,0) (11,10)
Initial centroids (first K points): C0=(0,0), C1=(10,10)

Iteration 1: sab points apne "obvious" nearest-centroid ko assign hote hai
             group = [0,1,0,1,0,1]  (point1,3,5 ka group PEHLI baar 0->1 badla)
             naye centroids: C0=(0.333,0.333), C1=(10.333,10.333)
             shift ≈ 0.471 (> tolerance) -> CONTINUE

Iteration 2: koi point apna group NAHI badalta (already sahi hai)
             centroids bhi NAHI hilte (shift=0) -> CONVERGED

FINAL:  centroids = (0.333333,0.333333) aur (10.333333,10.333333)
        WCSS = 2.666667, Iterations = 2, Converged = true
```
(Ye maine `/tmp/a4b kmeans` se compile+run karke EXACT verify kiya.)

### Real Test (km_01.txt: N=100, D=2, K=3)
```
Iterations: 2   Converged: true   WCSS: 16.616687
Final centroids: (0.51,0.48), (10.47,10.48), (20.50,20.48)
```
Sirf **2 iterations** mein converge ho gaya kyunki test-data me pehle 3
points HI teeno clusters ke "achhe representative" the (0,0 / 10,10 / 20,20
ke aas-paas) — matlab initialization "lucky" thi.

### ⚠️ Important Behaviour Note (code mein flag kiya hai)
`if(shift <= tol) done = true;` — ye line "done" ko FORCE-OVERRIDE kar sakti
hai CHAHE is iteration mein kisi point ka group badla ho. Matlab convergence
DO tarah se ho sakti hai: (a) koi point apna group nahi badalta, YA (b)
centroids bahut kam hilte hai — in dono mein se KOI EK true ho to loop ruk
jaata hai. Ye ek valid design-choice hai, lekin isse kabhi-kabhi "borderline"
points ka final assignment thoda arbitrary lag sakta hai.

---

## 3. FASTMAP — Concept + Verified Dry Run

### Idea (1 line mein)
"Humein objects ki ASLI coordinates nahi pata, sirf 'kaun kitna door hai
kisse' (pairwise distances) pata hai — FastMap in DISTANCES se hi unhe ek
chhoti k-dimensional Euclidean space mein PLACE kar deta hai."

### Vectors kyu banaye gaye
| Variable | Type | Kyu aisa? |
|---|---|---|
| `dist` | `vector<vector<double>>` | N×N SQUARE matrix (object i se object j tak distance) — pairwise hai isliye N×N, na ki N×D |
| `coord` | `vector<vector<double>>` | N objects, har ek ki k-dimensional NAYI coordinate — output "points" jaisa hi shape |
| `pivots` | `vector<pair<int,int>>` | har dimension ke liye EXACTLY 2 pivot-indices — chhota "2-tuple" ke liye pair<> kaafi hai |

### Har Dimension Ke 3 Steps
1. **Pivot chuno**: kisi bhi object se shuru karke uska farthest nikaalo (=a),
   fir a ka farthest nikaalo (=b) — ye ek CHEAP heuristic hai TRUE
   farthest-pair (jo O(N²) exhaustive search maangta) ka approximation.
2. **Coordinate nikaalo**: Cosine-Law jaisa formula —
   `x_i = (dist[a][i]² + ab² − dist[b][i]²) / (2·ab)`
   (triangle ke 3 sides se ek "projection" nikaalna, bilkul high-school
   geometry jaisa)
3. **Distances update karo**: Pythagoras se is-dimension ka "explained" farak
   HATA do, taaki AGLI dimension sirf BACHA HUA farak capture kare:
   `new_dist² = old_dist² − (coord[i][dim]−coord[j][dim])²`

### Verified Dry Run (fm_01.txt: N=10, K=2, dist(i,j)=|i−j| — matlab "ek seedhi line par baithe 10 points")
```
DIMENSION 1: pivots = (9, 0) [sabse dooriyon wale ends]
             ab = 9
             coord[i][0] = 9 − i     (i=0..9 -> 9,8,7,6,5,4,3,2,1,0)

Distance-update ke baad: SAB pairwise distances 0 ho jaate hai!
(kyunki data ASLI mein 1-DIMENSIONAL hi tha — dimension-1 ne
 SAARA "farak" already capture kar liya)

DIMENSION 2: pivots = (0, 0)   ab = dist[0][0] = 0
             if(ab <= 0) break;  -> LOOP YAHI RUK JAATA HAI
             coord[][1] apne DEFAULT value 0 par hi reh jaata hai

FINAL: pivots = [(9,0), (0,0)]
       coord = [(9,0), (8,0), (7,0), ..., (0,0)]
```
(Maine ye EXACT `fm_01.txt` compile+run karke verify kiya — match hua.)

**Isse KYA SEEKHA?** FastMap SAHI se pehchaanta hai ki agar data ASLI mein
1-dimensional tha, to sirf 1 "USEFUL" dimension hi nikaalta hai — dusri
dimension "khaali" reh jaati hai, jo bilkul EXPECTED/correct behaviour hai.
Real-world data (jo genuinely multi-dimensional hota hai) mein har dimension
kuch NAYA "farak" capture karegi.

---

## 4. Improvements / Observations

1. **`kmeans.cpp` mein `<algorithm>` include missing** hai (jabki `max()`
   use ho raha hai) — abhi transitively compile ho raha hai, lekin explicitly
   include karna chahiye (portable/safe code ke liye).

2. **`fastmap.h` mein `<utility>` include missing** hai (jabki `pair<int,int>`
   use ho raha hai) — same reasoning.

3. **K-Means initialization NAIVE hai**: "first K points" ko centroid banana
   simple hai, lekin agar pehle K points KHUD ek hi cluster ke ho (bad luck),
   to result kharab aa sakta hai. **K-Means++** jaisa smarter (probability-based)
   initialization zyada RELIABLE results deta hai.

4. **Empty-cluster case handle nahi hota properly**: agar koi cluster
   `cnt[c]==0` ho jaaye (koi point assign hi na ho), uska centroid
   FROZEN reh jaata hai (kabhi update nahi hota) — behtar practice hai
   use RANDOMLY kisi door point par reposition karna.

5. **FastMap `runFastMap()` "dist" ko BY VALUE leta hai** (na ki
   `const vector<...>&`), jisse poori N×N matrix ki COPY banti hai har call
   par. Chhote N ke liye theek hai, lekin N=10000 (fm_04.txt) jaise bade
   test ke liye ye MEMORY-HEAVY hai (~800MB extra copy). Agar caller ko
   purani matrix wapas nahi chahiye, move-semantics use kiya ja sakta hai.

6. **`val < 0` ko silently `0` kar diya jaata hai** (floating-point safety
   ke liye) — chhoti rounding-errors (jaise -1e-12) ke liye ye sahi hai,
   lekin agar `val` BAHUT negative ho (matlab input-distances ne TRIANGLE
   INEQUALITY follow nahi ki — invalid metric), to ye SILENTLY chhupa deta
   hai bina warning diye. Ek `cerr << "Warning: ..."` add karna chahiye.

7. **`driver.cpp` mein file-read validation kam hai** (`in >> n >> d >> k`
   ka return-value check nahi hota) — agar corrupt file di jaaye, to
   crash ya garbage output aa sakta hai bina clear error ke.

8. **`main()` mein usage-error par `return 0`** hota hai (na ki `return 1`)
   — shell-scripts ke liye ye "success" jaisa treat hoga chahe command
   GALAT ho di gayi ho. `return 1` zyada standard practice hai.

9. **`Makefile` ka `clean:` target Windows-only hai** (`del /Q`) — Linux/Mac
   ke liye `rm -f assignment4_buddy.exe` wala target bhi add karna chahiye.

---

## 5. Kaise Compile/Run Karein

```bash
g++ -std=c++17 -o assignment4_buddy driver/driver.cpp src/kmeans.cpp src/fastmap.cpp

./assignment4_buddy kmeans tests/km_01.txt
./assignment4_buddy fastmap tests/fm_01.txt
```
(Maine ye commands khud chalake dry-run outputs verify kiye hai.)

`tests/make_fm_04.py` ek Python script hai jo bada (10000×10000) distance-matrix
test-file `fm_04.txt` generate karta hai (`d(i,j)=|i-j|` formula se, jo
symmetric, zero-diagonal aur triangle-inequality follow karta hai) — isliye wo
file zip mein directly included NAHI hai, script se generate karni padegi:
```bash
cd tests && python make_fm_04.py
```

---

## 6. Quick Glossary

- **Centroid** = ek cluster ka "average position" (uska representative point)
- **WCSS** = Within-Cluster Sum of Squares — clustering kitni "tight" hai, iska measure
- **Convergence** = jab algorithm ki values iteration-dar-iteration badalna band kar de
- **Pivot (FastMap mein)** = do "extreme/far-apart" objects jo ek dimension define karte hai
- **Projection** = kisi point ko ek line/axis par "gira dena" (uski us-axis-wali coordinate nikaalna)
- **Cosine Law** = triangle ke 3 sides se ek angle/projection nikaalne ka formula (high-school geometry)
