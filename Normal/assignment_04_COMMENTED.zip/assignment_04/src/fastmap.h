#ifndef FASTMAP_H
#define FASTMAP_H

#include <vector>     // vector<> ke liye
using namespace std;
// ⚠️ NOTE: neeche `pair<int,int>` use ho raha hai, jiske liye technically
// <utility> header chahiye. Ye is waqt compile ho jaata hai kyunki <vector>
// practically <utility> ko transitively include kar deta hai (GCC mein),
// lekin STANDARD ke hisaab se GUARANTEED nahi hai. IMPROVEMENT: `#include
// <utility>` explicitly add karo.

// FastMapResult: FastMap chalane ke baad jo bhi cheezein caller ko chahiye,
// unko bundle karne wala struct.
struct FastMapResult
{
    vector<vector<double>> coord;
    // coord[i] = object 'i' ki NAYI k-dimensional coordinates (jo humne
    // "pairwise distances" se NIKAALI hai). Ye bhi "vector of vectors" hai
    // isi wajah se jaisi center[] thi kmeans mein — har object khud ek
    // k-numbers ka point ban jaata hai.
    // Example: agar k=2, to coord[3] = {x,y} -> object-3 ki 2D coordinate

    vector<pair<int,int>> pivots;
    // pivots[dim] = {objectA, objectB} -> is dimension ke liye CHUNE GAYE
    // do "sabse door" (pivot) objects ke indices.
    // "pair<int,int>" isliye kyunki har dimension ke liye EXACTLY 2 numbers
    // (dono pivot-indices) store karne hai — ek chhota "2-tuple" ke liye
    // poora struct banane ki zaroorat nahi, std::pair kaafi hai.
};

// runFastMap: pairwise-DISTANCES (N x N matrix) se objects ki k-dimensional
// COORDINATES nikaalta hai (bina unki ASLI coordinates jaane — sirf ye
// pata hokar ki "kaun kitna door hai kisse", FastMap unhe ek chhoti k-dim
// space mein "place" kar deta hai, taaki visualize/further-processing ho sake).
//
// dist: N x N distance matrix, dist[i][j] = object i aur j ke beech distance
//       (⚠️ NOTE: "vector<vector<double>> dist" -- BY VALUE liya gaya hai,
//        na ki "const &" reference se! Matlab poori N×N matrix ki COPY
//        function ke andar banti hai. Bade N (jaise N=10000) ke liye ye
//        MAHENGA hai — 10000×10000×8bytes ≈ 800MB ki EXTRA copy ban jaati
//        hai sirf function-call ke liye! Lekin ye "by value" hona
//        INTENTIONAL bhi ho sakta hai, kyunki andar FUNCTION khud dist[][]
//        ko MODIFY karta hai — agar reference leta, to caller ki ASLI
//        matrix bhi badal jaati. IMPROVEMENT: agar caller ko purani matrix
//        chahiye hi nahi baad mein, to move-semantics (`vector<...>&&`) use
//        karke ye copy AVOID ki ja sakti hai.)
// k: kitni dimensions mein "project" karna hai (target dimensionality)
FastMapResult runFastMap(vector<vector<double>> dist, int k);

#endif
