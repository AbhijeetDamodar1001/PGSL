#include "kmeans.h"
#include <cmath>       // sqrt() ke liye
#include <limits>      // is file mein directly use nahi ho raha (dekh lo neeche IMPROVEMENT note mein)
// ⚠️ NOTE: `max()` function neeche (line ~77 wagera) use ho raha hai lekin
// <algorithm> header YAHAN INCLUDE NAHI hai! Ye is waqt COMPILE ho jaata hai
// kyunki <cmath>/<limits> practically GCC mein <algorithm> ko transitively
// khींच lete hai, lekin ye GUARANTEED behaviour nahi hai — kisi aur compiler
// par FAIL ho sakta hai. IMPROVEMENT: `#include <algorithm>` explicitly add karo.

/* ============================================================================
   dist2() : DO POINTS ke beech SQUARED EUCLIDEAN DISTANCE nikaalta hai.
   "SQUARED" isliye (sqrt() nahi liya) kyunki K-Means mein hume sirf "KAUNSA
   centroid SABSE PAAS hai" janna hota hai — comparison ke liye sqrt() lena
   ZAROORI NAHI (kyunki agar a² < b² to a < b bhi hota hai, jab tak a,b>=0).
   Isse har baar EXPENSIVE sqrt() call SAVE ho jaata hai (performance optimization).
   ============================================================================ */
static double dist2(const vector<double>& a, const vector<double>& b)
{
    double s = 0;                              // running sum of squared differences
    for (int i = 0; i < (int)a.size(); i++)      // har DIMENSION (jaise x, y, z...) ke liye
    {
        double x = a[i] - b[i];                   // us dimension mein farak
        s += x * x;                                 // farak ka square, total mein jod do
    }
    return s;
    // Example: a=(0,0), b=(3,4) -> dist2 = (0-3)² + (0-4)² = 9+16 = 25
    // (asli Euclidean distance hota sqrt(25)=5, lekin hume sirf 25 hi chahiye)
}

/* ============================================================================
   DRY RUN EXAMPLE (chhota, HAATH SE VERIFY kiya + KHUD COMPILE KARKE bhi
   CONFIRM kiya — exact match mila):

   6 points, K=2, D=2 dimensions:
     p0=(0,0)  p1=(10,10)  p2=(0,1)  p3=(10,11)  p4=(1,0)  p5=(11,10)

   ---- START ----
   center[0] = points[0] = (0,0)     <- "first K points" hi initial centroids hai
   center[1] = points[1] = (10,10)
   group[] = [0,0,0,0,0,0]   (start mein sab default 0)

   ---- ITERATION 1 (it=1) ----
   done = true (shuru mein maan lo "kuch nahi badlega")

   Har point ko NEAREST centroid do:
     p0=(0,0):  dist2(p0,C0)=0,    dist2(p0,C1)=200  -> C0 nearest -> group[0]=0 (SAME as before, no flip)
     p1=(10,10):dist2(p1,C0)=200,  dist2(p1,C1)=0    -> C1 nearest -> group[1]=1 (CHANGE! done=false)
     p2=(0,1):  dist2(p2,C0)=1,    dist2(p2,C1)=181  -> C0 nearest -> group[2]=0 (same)
     p3=(10,11):dist2(p3,C0)=221,  dist2(p3,C1)=1    -> C1 nearest -> group[3]=1 (CHANGE! done=false)
     p4=(1,0):  dist2(p4,C0)=1,    dist2(p4,C1)=181  -> C0 nearest -> group[4]=0 (same)
     p5=(11,10):dist2(p5,C0)=221,  dist2(p5,C1)=1    -> C1 nearest -> group[5]=1 (CHANGE! done=false)

   group[] = [0,1,0,1,0,1]     done = false (kyunki kai points ka group BADLA)

   Naye centroids nikaalo (har cluster ke apne points ka AVERAGE):
     cluster0 = {p0,p2,p4} = (0,0)+(0,1)+(1,0) = (1,1) -> average = (1/3, 1/3) = (0.333, 0.333)
     cluster1 = {p1,p3,p5} = (10,10)+(10,11)+(11,10) = (31,31) -> average = (31/3,31/3) = (10.333, 10.333)

   shift = kitna centroid HILA (Euclidean distance old->new):
     C0: (0,0) -> (0.333,0.333): sqrt(0.333²+0.333²) ≈ 0.471
     C1: (10,10) -> (10.333,10.333): sqrt(0.333²+0.333²) ≈ 0.471
     shift = max(0.471, 0.471) = 0.471

   shift(0.471) > tol(0.0001) -> "if(shift<=tol) done=true" TRIGGER NAHI hota
   -> done abhi bhi FALSE hai (group change ki wajah se), LOOP CONTINUE hoga

   ---- ITERATION 2 (it=2) ----
   done = true (fir se reset)

   Naye centroids C0=(0.333,0.333), C1=(10.333,10.333) ke against points check karo:
     p0,p2,p4 (jo pehle bhi C0 ke paas the) -> ABHI BHI C0 hi nearest hai -> group SAME (koi flip nahi)
     p1,p3,p5 -> ABHI BHI C1 hi nearest hai -> group SAME (koi flip nahi)

   group[] = [0,1,0,1,0,1]   (BILKUL SAME as pehle)  done = TRUE (koi bhi point ka group nahi badla!)

   Centroids dobara recompute karo -> SAME clusters ke SAME points -> SAME
   centroids aate hai (0.333,0.333) aur (10.333,10.333) -> shift = 0

   shift(0) <= tol(0.0001) -> done=true (ye bhi confirm karta hai)

   LOOP KHATAM (done==true): iterations=2, converged=true

   ---- FINAL WCSS ----
   cluster0 points (0,0),(0,1),(1,0) apne centroid (0.333,0.333) se:
     (0,0): (0.333)²+(0.333)² = 0.111+0.111 = 0.222
     (0,1): (0.333)²+(0.667)² = 0.111+0.445 = 0.556
     (1,0): (0.667)²+(0.333)² = 0.445+0.111 = 0.556
     cluster0 subtotal = 1.334
   cluster1 SYMMETRIC hai (same shape data, +10 shift) -> subtotal bhi 1.334
   WCSS = 1.334 + 1.334 = 2.667

   ✅ MAINE YE EXACT INPUT KHUD COMPILE+RUN KARKE VERIFY KIYA:
      Final centroids: 0.333333 0.333333  /  10.333333 10.333333
      WCSS: 2.666667   Iterations: 2   Converged: true
   (Poora hisaab MATCH hua — ye trace bilkul sahi hai)
   ============================================================================ */

KMeansResult runKMeans(const vector<vector<double>>& points,
                       int k, int maxIter, double tol)
{
    int n = (int)points.size();          // total kitne points hai (DRY RUN: n=6)
    int d = (int)points[0].size();        // har point mein kitne dimensions hai (DRY RUN: d=2)

    // ---------- STEP 1: Initial centroids = pehle K points ----------
    vector<vector<double>> center(k, vector<double>(d));
    // "vector<vector<double>> center" KYUN? Kyunki HAR centroid khud EK
    // D-dimensional point hai (jaise 2D data ke liye centroid = {x,y}), aur
    // humein K aise centroids chahiye — isliye "K centroids ki list, har
    // centroid D-numbers ka" = vector of K vectors, har inner vector size D.

    for (int i = 0; i < k; i++)
        center[i] = points[i];
        // README.txt ke MUTABIK: "The first K points are used as the
        // starting centroids" — ye EK SIMPLE (lekin thoda NAIVE) initialization
        // hai. IMPROVEMENT: "K-Means++" jaisa smarter initialization use kiya
        // ja sakta hai jo BEHTAR/CONSISTENT results deta hai (random seed ke
        // bina bhi), khaaske agar pehle K points KHUD SAME cluster ke ho
        // (jo BURA initial guess dega).
        // DRY RUN: center[0]=(0,0), center[1]=(10,10)

    vector<int> group(n, 0);
    // group[i] = point i KIS cluster mein hai. Shuru mein sab 0 (default),
    // "vector<int>" isliye kyunki har point ko sirf EK cluster-number (int) chahiye

    bool done = false;    // "converge ho gaya kya" flag
    int it = 0;            // kitni iterations ho chuki

    // ---------- MAIN LOOP: jab tak (a) maxIter na aaye AUR (b) converge na ho ----------
    while (it < maxIter && !done)
    {
        it++;
        done = true;    // is iteration ki SHURUAAT mein maan lo "kuch nahi badlega"
                          // (agar aage koi point apna group badalta hai, to ye false ho jayega)

        // ---------- STEP 2: ASSIGNMENT — har point ko SABSE PAAS wala centroid do ----------
        for (int i = 0; i < n; i++)     // har point ke liye
        {
            int best = 0;                                    // ab tak ka best cluster (start: cluster0)
            double bestDist = dist2(points[i], center[0]);     // cluster0 se distance

            for (int c = 1; c < k; c++)     // baaki (1 se k-1) clusters se compare karo
            {
                double x = dist2(points[i], center[c]);
                if (x < bestDist)
                    // agar ye centroid PEHLE se BEHTAR (chhota distance) hai
                {
                    bestDist = x;
                    best = c;
                }
            }

            if (group[i] != best)
                // agar point ka NAYA best-cluster PURANE se ALAG hai
                done = false;    // matlab kuch to BADLA -> abhi convergence nahi hui

            group[i] = best;     // point ko naya cluster assign kardo
            // DRY RUN (iteration1, i=0): points[0]=(0,0), dist2-to-C0=0, dist2-to-C1=200
            //          -> best=0, group[0] pehle se 0 tha -> koi flip nahi
            // DRY RUN (iteration1, i=1): points[1]=(10,10), dist-to-C0=200,dist-to-C1=0
            //          -> best=1, group[1] pehle 0 tha ab 1 -> done=false (CHANGE!)
        }

        // ---------- STEP 3: UPDATE — har cluster ke naye centroid (average) nikaalo ----------
        vector<vector<double>> sum(k, vector<double>(d, 0));
        // sum[c] = cluster 'c' ke SAARE points ka COORDINATE-WISE TOTAL
        // (baad mein count se divide karke AVERAGE nikalenge)
        vector<int> cnt(k, 0);
        // cnt[c] = cluster 'c' mein KITNE points hai (average nikalne ke liye divisor chahiye)

        for (int i = 0; i < n; i++)          // har point ko uske assigned cluster ke sum mein jodo
        {
            cnt[group[i]]++;
            for (int j = 0; j < d; j++)
                sum[group[i]][j] += points[i][j];
        }
        // DRY RUN (iteration1): cluster0={p0,p2,p4} -> cnt[0]=3, sum[0]=(0+0+1, 0+1+0)=(1,1)
        //                        cluster1={p1,p3,p5} -> cnt[1]=3, sum[1]=(10+10+11,10+11+10)=(31,31)

        double shift = 0;     // is iteration mein centroids KITNA hile (max over all clusters)

        for (int c = 0; c < k; c++)
        {
            if (cnt[c] == 0)
                continue;
                // ⚠️ EDGE CASE: agar KISI cluster mein EK BHI point assign
                // nahi hua (cnt[c]==0), to us cluster ka centroid UPDATE
                // NAHI hota (purana hi reh jaata hai) — divide-by-zero se
                // bachne ke liye ye zaroori hai, lekin isse wo cluster
                // "DEAD"/"EMPTY" reh sakta hai poore algorithm mein
                // (IMPROVEMENT: aisi situation mein us centroid ko RANDOMLY
                //  reposition karna behtar practice hoti hai)

            vector<double> next = center[c];        // temp copy (size/shape match karne ke liye)
            for (int j = 0; j < d; j++)
                next[j] = sum[c][j] / cnt[c];
                // AVERAGE = total / count -> yehi NAYA centroid hai
                // DRY RUN: next[0] = (1/3, 1/3) = (0.333, 0.333)

            shift = max(shift, sqrt(dist2(center[c], next)));
            // is centroid ka OLD-se-NEW distance nikaalo (sqrt() yahan LIYA
            // gaya hai kyunki humein ASLI distance chahiye "tol" se compare
            // karne ke liye, na ki sirf comparison — dist2() jaisa squared-shortcut yahan nahi chalega)
            // DRY RUN: sqrt(dist2((0,0),(0.333,0.333))) = sqrt(0.222) ≈ 0.471

            center[c] = next;    // centroid officially UPDATE kardo
        }

        if (shift <= tol)
            // agar SAB centroids MILAKAR bhi bahut kam hile (tolerance se kam)
            done = true;
            // ⚠️ IMPORTANT BEHAVIOUR: Ye line "done" ko OVERRIDE kar sakti hai
            // CHAHE upar "group[i] != best" ki wajah se done=false ho chuka ho!
            // Matlab: agar is iteration mein kisi point ka GROUP badla (bahut
            // chhoti si baat), LEKIN centroid-shift phir bhi chhota hai, to
            // algorithm RUK jayega — "group changed" hone ke bawajood.
            // Ye DESIGN CHOICE hai (dono convergence-criteria — group-stability
            // AUR centroid-stability — mein se KOI BHI EK convergence maan
            // liya jaata hai), lekin technically iska matlab ho sakta hai ki
            // kuch points "borderline" (do centroids ke beech) reh jaaye aur
            // unka final group assignment thoda ARBITRARY lage.
    }

    // ---------- STEP 4: FINAL WCSS (Within-Cluster Sum of Squares) nikaalo ----------
    double wcss = 0;
    for (int i = 0; i < n; i++)
        wcss += dist2(points[i], center[group[i]]);
        // har point apne FINAL assigned-centroid se kitna door hai (squared),
        // sabko jod diya -> "clustering kitni tight hai" ka overall measure
    // DRY RUN: wcss = 0.222+0.556+0.556 (cluster0) + 0.222+0.556+0.556 (cluster1) = 2.667

    KMeansResult ans;
    ans.group = group;
    ans.center = center;
    ans.iterations = it;
    ans.wcss = wcss;
    ans.converged = done;
    return ans;
    // DRY RUN FINAL RESULT: group=[0,1,0,1,0,1], center=[(0.333,0.333),(10.333,10.333)],
    //                        iterations=2, wcss=2.667, converged=true
    // (Maine ye EXACT input khud compile+run karke bhi verify kiya — match hua!)
}
