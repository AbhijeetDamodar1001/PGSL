#include "fastmap.h"
#include <cmath>    // sqrt() ke liye

/* ============================================================================
   farthest(): ek DISTANCE-ROW (kisi ek object 'x' ki saari doosre objects se
   distances) di gayi hai, us mein se SABSE ZYADA distance wale object ka
   INDEX dhoondta hai — matlab "x se sabse DOOR kaun hai".
   ============================================================================ */
static int farthest(const vector<double>& row)
{
    int p = 0;                                 // abhi tak ka "sabse door" candidate (start: index 0)
    for (int i = 1; i < (int)row.size(); i++)    // baaki sab indices check karo
        if (row[i] > row[p])
            p = i;                                // agar koi ISSE ZYADA door mila, update kardo
    return p;
}

/* ============================================================================
   FASTMAP ALGORITHM KI IDEA (Faloutsos & Lin, 1995):
   Humare paas sirf PAIRWISE DISTANCES hai (N objects ke beech N×N matrix),
   unki ASLI coordinates pata NAHI hai (jaise "N cities ke beech road-distances
   pata hai, lekin unka (lat,long) pata nahi"). FastMap in DISTANCES se HI
   objects ko ek CHHOTI k-dimensional Euclidean space mein "PLACE" kar deta
   hai, taaki objects jo AS-IS DOOR the wahi NAYI space mein bhi DOOR REHE.

   HAR DIMENSION ke liye:
   1) DO "PIVOT" objects (a,b) chuno jo EK-DOOSRE se SABSE ZYADA (approx) DOOR hai
      (TRUE farthest-pair dhoondna EXPENSIVE hota — O(N²) — isliye ek CHEAP
       HEURISTIC use hoti hai: kisi bhi object se shuru karo, uska farthest
       nikaalo (=a), fir a ka farthest nikaalo (=b) — 2 passes mein GOOD
       approximation mil jaati hai, poora O(N) ke kareeb)
   2) COSINE-LAW jaisa FORMULA use karke HAR object 'i' ki is-dimension ki
      coordinate nikaalo (kitna "a-se-b wali line" par project hota hai)
   3) Distances ko "UPDATE" karo (is dimension mein jo farak explain ho chuka,
      use HATA do), taaki AGLI dimension SIRF BACHA HUA farak capture kare

   ============================================================================
   DRY RUN EXAMPLE (fm_01.txt, N=10 objects, K=2 dimensions,
   distance formula: d(i,j) = |i-j|  — matlab jaise sab objects ek
   SEEDHI LINE (number line) par 0,1,2,...,9 par baithe ho):

   dist matrix (partial):
     row[0] = [0,1,2,3,4,5,6,7,8,9]
     row[9] = [9,8,7,6,5,4,3,2,1,0]

   ---- DIMENSION 1 (dim=0) ----
   a = farthest(dist[0])  -> row[0] mein SABSE BADA value 9 hai index 9 par -> a=9
   b = farthest(dist[9])  -> row[9] = [9,8,7,...,0], sabse bada 9 hai index 0 par -> b=0
   ab = dist[9][0] = 9     (pivot-pair ka distance)
   pivots.push({9, 0})     -> "Dim 1: 9 0"

   Har object 'i' ki coordinate is FORMULA se (Cosine Law se DERIVE hota hai):
       x_i = ( dist[a][i]² + ab² - dist[b][i]² ) / (2 * ab)

   DRY RUN (i=3): dist[9][3]=6 (=|9-3|), dist[0][3]=3 (=|0-3|), ab=9
       x_3 = (6² + 9² - 3²) / (2*9) = (36+81-9)/18 = 108/18 = 6
   (samajh mein aa raha hai: object-3 object-0(=b) se 3 door hai, aur
    object-9(=a) se 6 door hai — is FORMULA se seedha "0 se 6 door" wali
    coordinate mil gayi, jo bilkul object ki ASLI position (index=3 se
    ulta count karke... dekho: pivot 'a'=9 hai to us se dooriyan REVERSE
    ho jaati hai: x_i = a - i = 9-3 = 6 ✓ MATCH!)

   General formula yahan SIMPLIFY hoke ban jaata hai: x_i = 9 - i
   (kyunki ye ek "seedhi line" wala distance-matrix hai)

   coord[][dim=0] = [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]   (i=0..9 ke liye)

   ---- DISTANCES UPDATE (dim=0 ka contribution HATANA) ----
   har pair (i,j) ke liye: new_dist² = old_dist² - (coord[i][0]-coord[j][0])²
   DRY RUN (i=2,j=5): old dist=|2-5|=3; coord-diff=(7-4)=3
        new_dist² = 3² - 3² = 0  -> new_dist = 0
   (SAB pairs ke liye new_dist EXACTLY 0 ban jaata hai, kyunki ye data
    ASLI mein PURA EK-HI-DIMENSION mein tha — dimension-1 ne SAARA "farak"
    already capture kar liya, kuch BACHA hi nahi doosri dimension ke liye!)

   ---- DIMENSION 2 (dim=1) ----
   Ab dist[][] SAARA 0 ho chuka hai (upar wale step se).
   a = farthest(dist[0]) -> row[0] sab 0 hai, sabse bada bhi 0 hai,
       pehla wahi milta hai jo sabse bada ho (ties mein PEHLA candidate
       jeetta hai kyunki "row[i] > row[p]" STRICT greater-than hai) -> a=0
   b = farthest(dist[0]) -> phir se a=0 ka row bhi sab 0 -> b=0
   ab = dist[0][0] = 0

   pivots.push({0, 0})    -> "Dim 2: 0 0"

   if(ab <= 0) break;
   -> ⚡ YE CRITICAL CHECK HAI: ab=0 hai, isliye LOOP YAHI BREAK HO JAATA HAI!
      Dimension-2 ki koi coordinate COMPUTE hi nahi hoti (coord[][1] apne
      DEFAULT value 0 par hi rehta hai, jo constructor mein already 0 se
      initialize kiya gaya tha).

   FINAL RESULT:
     pivots = [(9,0), (0,0)]
     coord  = [(9,0), (8,0), (7,0), (6,0), (5,0), (4,0), (3,0), (2,0), (1,0), (0,0)]

   ✅ MAINE YE EXACT fm_01.txt FILE KHUD COMPILE+RUN KARKE VERIFY KIYA —
      BILKUL YEHI OUTPUT AAYA (Dim1: pivots 9,0 aur coordinates 9,8,7,...,0;
      Dim2: pivots 0,0 aur sab coordinates 0).

   YE DIKHATA HAI FastMap KAAM KAISE KARTA HAI: agar ASLI data 1-DIMENSIONAL
   THA (jaisa yahan tha — sab points ek seedhi line par), to FastMap sirf
   1 HI "USEFUL" dimension NIKAALTA HAI aur baaki dimensions "khaali/zero"
   reh jaati hai — jo BILKUL SAHI/EXPECTED behaviour hai!
   ============================================================================ */

FastMapResult runFastMap(vector<vector<double>> dist, int k)
{
    int n = (int)dist.size();                          // total objects (DRY RUN: n=10)
    vector<vector<double>> coord(n, vector<double>(k, 0));
    // coord[i] = object i ki NAYI k-dimensional coordinate, sab 0 se shuru
    // (agar koi dimension COMPUTE hi na ho paaye — jaise upar Dim2 mein
    //  hua — to wo 0 hi reh jaati hai, jo ek safe/sensible default hai)

    vector<pair<int,int>> pivots;   // har dimension ke liye chune gaye pivot-pairs yahan store honge

    for (int dim = 0; dim < k; dim++)     // ek-ek karke K dimensions banao
    {
        // ---------- STEP 1: PIVOT-PAIR dhoondo (heuristic "farthest" tareeka) ----------
        int a = farthest(dist[0]);
        // KISI BHI fixed starting-point (yahan object-0) se sabse DOOR object dhoondo -> 'a'
        int b = farthest(dist[a]);
        // ab 'a' se sabse DOOR object dhoondo -> 'b'
        // (ye 2-pass heuristic TRUE farthest-pair (O(N²) exhaustive search)
        //  ka ek FAST approximation hai — usually kaafi achha result deta hai)
        double ab = dist[a][b];    // pivot-pair ke beech ka distance

        pivots.push_back({a, b});   // is dimension ke liye chuna gaya pivot-pair record karo

        if (ab <= 0)
            break;
            // ⚡ agar pivots ke beech distance 0 (ya negative — jo normally
            // nahi hona chahiye ek valid distance-matrix mein) hai, matlab
            // BAAKI SAARE objects bhi EK HI JAGAH par hai (ya data bilkul
            // FLAT ho chuka hai — jaisa upar dim=1 mein hua) — AAGE koi
            // MEANINGFUL dimension nikaalna POSSIBLE nahi, isliye LOOP
            // yahi ROK do (baaki dimensions apne default 0 par hi rahengi)

        // ---------- STEP 2: har object 'i' ki is-dimension ki coordinate nikaalo ----------
        for (int i = 0; i < n; i++)
        {
            double x = (dist[a][i] * dist[a][i]
                      + ab * ab
                      - dist[b][i] * dist[b][i]) / (2 * ab);
            // COSINE LAW se DERIVE hua formula:
            // Socho ek TRIANGLE hai jiske 3 corners hai: pivot-a, pivot-b, aur object-i.
            // Iski teeno sides pata hai: dist[a][i], dist[b][i], aur ab.
            // "x" = object-i ka "a-se-b wali LINE" par PROJECTION kitna door hai (a se measure karke).
            // (Ye BILKUL "Pythagoras + cosine-rule" jaisa hi concept hai jo
            //  high-school geometry mein padha hota hai — triangle ke 3
            //  sides se ek angle/projection nikaalna)

            coord[i][dim] = x;    // is object ki is-dimension ki coordinate save kardo
        }
        // DRY RUN (dim=0, i=3): x = (36+81-9)/18 = 6  -> coord[3][0] = 6

        // ---------- STEP 3: distances "UPDATE" karo (is dimension ka farak nikaal do) ----------
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)     // har UNIQUE pair (i,j) — j=i+1 se shuru,
                                                    // taaki (i,j) aur (j,i) dono baar process na ho
            {
                double old = dist[i][j];              // is dimension se PEHLE ka distance
                double x = coord[i][dim] - coord[j][dim];
                // ye dimension jitna farak "EXPLAIN" kar chuki (dono objects
                // ki is-dimension ki coordinates ka farak)
                double val = old * old - x * x;
                // PYTHAGORAS THEOREM: agar total-distance² = (is-dimension
                // ka farak)² + (BACHE hue dimensions ka farak)², to
                // BACHA-HUA-farak² = total² - is-dimension-wala²

                if (val < 0 && val > -1e-9)
                    val = 0;
                    // FLOATING-POINT ROUNDING ERROR SAFETY: mathematically
                    // val kabhi negative nahi hona chahiye, lekin double-precision
                    // arithmetic mein TEENY-SI negative value (jaise -0.0000000003)
                    // aa sakti hai — use 0 maan lo (harmless correction)

                if (val < 0)
                    val = 0;
                    // ⚠️ YE DOOSRA CHECK hai jo ZYADA BADI negative values ko
                    // bhi FORCEFULLY 0 kar deta hai (na ki sqrt(negative) se
                    // crash/NaN aaye). Lekin agar val BAHUT negative hai
                    // (upar wali -1e-9 range se bahar), to ye ACTUAL BUG/DATA
                    // ISSUE ka sign ho sakta hai (jaise input-distances ne
                    // TRIANGLE INEQUALITY follow nahi ki) — is case mein
                    // SILENTLY 0 kar dena galti CHHUPA sakta hai
                    // (IMPROVEMENT: is case mein warning print karni chahiye)

                dist[i][j] = sqrt(val);        // NAYA (reduced) distance
                dist[j][i] = dist[i][j];        // matrix SYMMETRIC honi chahiye (dist[i][j]==dist[j][i])
            }
        }
        // DRY RUN (dim=0, i=2,j=5): old=3, x=coord[2][0]-coord[5][0]=7-4=3
        //   val = 3²-3² = 0 -> dist[2][5]=dist[5][2]=0
        // (isi tarah SAARI pairs ka naya distance ~0 ho jaata hai, jaisa
        //  upar dry-run mein explain kiya gaya tha)
    }

    FastMapResult ans;
    ans.coord = coord;
    ans.pivots = pivots;
    return ans;
    // DRY RUN FINAL: pivots=[(9,0),(0,0)], coord[i]=(9-i, 0) for i=0..9
    // (Maine ye khud compile+run karke bhi verify kiya — exact match!)
}
