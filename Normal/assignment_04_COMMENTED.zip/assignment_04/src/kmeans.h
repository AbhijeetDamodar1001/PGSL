#ifndef KMEANS_H
#define KMEANS_H

#include <vector>     // vector<> container use karne ke liye chahiye
using namespace std;

// KMeansResult: K-Means chalane ke baad JO BHI cheezein caller ko chahiye
// hoti hai, unko ek jagah bundle karke rakhne wala struct.
// (Ek function se ek saath MULTIPLE cheezein return karni ho to C++ mein
//  ya to struct banao, ya reference-parameters use karo — yahan struct
//  wala tareeka chuna gaya hai, jo zyada CLEAN/readable hai)
struct KMeansResult
{
    vector<int> group;
    // group[i] = point 'i' KIS cluster (0 se K-1) mein daala gaya.
    // Example: agar 5 points hai aur K=2, to group = [0,1,0,0,1] jaisa kuch
    // ho sakta hai (matlab point0,2,3 cluster-0 mein hai; point1,4 cluster-1 mein)

    vector<vector<double>> center;
    // center[c] = cluster 'c' ka FINAL centroid (average position).
    // Ye ek "vector of vectors" hai kyunki HAR centroid khud ek D-dimensional
    // point hai (jaise 2D data ke liye center[c] = {x, y}).
    // Example: center = [{0.33,0.33}, {10.33,10.33}]  (2 clusters, 2D data)

    int iterations;
    // total kitni baar "assign points -> update centroids" loop chala

    double wcss;
    // WCSS = Within-Cluster Sum of Squares. Ye batata hai ki clustering
    // KITNI "TIGHT" hai — har point apne centroid se kitna door hai (squared),
    // sabko jod diya. CHHOTA WCSS = BEHTAR (tight) clustering.

    bool converged;
    // true = algorithm "settle" ho gaya (aage badalna band ho gaya)
    // false = maxIter tak pahunch gaya lekin abhi bhi stable nahi hua tha
};

// runKMeans: ASLI K-Means algorithm chalane wala function.
// points: input data — HAR point khud ek vector<double> hai (D-dimensional
//         coordinates), aur poore dataset ke liye N aise points hai
//         (isliye "vector<vector<double>>" — outer vector = N points,
//         inner vector = har point ke D coordinates)
// k: kitne clusters banane hai
// maxIter: kitni baar tak max loop chalega (safety-limit, infinite-loop na ho)
// tol: "tolerance" — agar centroids itna KAM (ya kam) hile ek iteration mein,
//      to maano algorithm "converge" ho gaya, ruk jao
KMeansResult runKMeans(const vector<vector<double>>& points,
                       int k, int maxIter, double tol);

#endif
