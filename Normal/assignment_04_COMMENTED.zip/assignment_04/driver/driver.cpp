#include <iostream>
#include <fstream>      // file se test-data padhne ke liye (ifstream)
#include <vector>
#include <string>
#include <chrono>        // execution-time measure karne ke liye
#include <iomanip>       // setprecision()/fixed ke liye (decimal output formatting)
#include "../src/kmeans.h"
#include "../src/fastmap.h"

using namespace std;

/* ============================================================================
   YE DRIVER EK "SWITCH-BOARD" HAI — command-line ke pehle argument
   ("kmeans" ya "fastmap") ke hisaab se decide karta hai KAUNSA algorithm
   chalana hai aur KIS test-file se data padhna hai.
   ============================================================================ */

void runKMeansFile(const string& file)
{
    ifstream in(file);
    if (!in)
    {
        cout << "Could not open file.\n";
        return;
        // NOTE: koi error-CODE return nahi ho raha (function `void` hai) —
        // agar file na khule, program "Could not open file." print karke
        // bina crash kiye seedha aage badh jaata hai (main() mein return 0 hi hoga)
    }

    int n, d, k;
    in >> n >> d >> k;
    // FILE FORMAT: pehli line = "N D K" (kitne points, kitni dimensions, kitne clusters)
    // DRY RUN (km_01.txt): n=100, d=2, k=3
    // ⚠️ NOTE: yaha bhi (poore project ki tarah) `>>` ka return-value CHECK
    // nahi ho raha — agar file corrupt/khaali ho to n/d/k GARBAGE (ya 0)
    // reh sakte hai, aur aage vector-resize CRASH kar sakta hai (n<0 jaisa
    // case) — IMPROVEMENT: `if(!(in>>n>>d>>k) || n<=0 || d<=0 || k<=0)` check honi chahiye

    vector<vector<double>> points(n, vector<double>(d));
    // "points" ek N×D matrix hai: N points, har point D coordinates ka
    // (vector<vector<double>> isliye, taaki HAR POINT apni khud ki D-size
    //  ki chhoti list rakh sake — flexible/dynamic hai, D compile-time
    //  fixed nahi hai, file se PADH KE pata chalta hai)

    for (int i = 0; i < n; i++)         // har point ki
        for (int j = 0; j < d; j++)      // har coordinate padho
            in >> points[i][j];
    // DRY RUN (km_01.txt): points[0] = (0.0000, 0.0000), points[1] = (10.0300, 10.0400), ...

    string word;      // "MAX_ITERATIONS" aur "TOLERANCE" jaise LITERAL keywords yaha padhenge
    int maxIter;
    double tol;
    in >> word >> maxIter;
    // DRY RUN: word="MAX_ITERATIONS", maxIter=300
    in >> word >> tol;
    // DRY RUN: word="TOLERANCE", tol=0.0001
    // NOTE: "word" variable REUSE ho raha hai dono baar — pehli baar
    // "MAX_ITERATIONS" store karega, dusri baar "TOLERANCE" se OVERWRITE ho
    // jayega. Chhota/valid optimization hai (naya variable banane ki zaroorat nahi)

    // ---------- ASLI ALGORITHM CHALAO, TIME MEASURE KARTE HUE ----------
    auto start = chrono::high_resolution_clock::now();     // stopwatch START
    KMeansResult ans = runKMeans(points, k, maxIter, tol);
    auto stop = chrono::high_resolution_clock::now();       // stopwatch STOP

    double time = chrono::duration<double, milli>(stop - start).count();
    // duration ko MILLISECONDS mein double ke roop mein nikala

    // ---------- OUTPUT PRINT KARO ----------
    cout << "\nAlgorithm: K-Means Clustering\n";
    cout << "K: " << k << "\n";
    cout << "Point assignments:\n";
    for (int i = 0; i < n; i++)
        cout << i << " " << ans.group[i] << "\n";
        // DRY RUN OUTPUT: "0 0\n1 1\n2 2\n3 0\n..." (point-index aur uska cluster)

    cout << "Final centroids:\n";
    cout << fixed << setprecision(6);
    // `fixed` + `setprecision(6)` -> saare AAGE aane wale doubles HAMESHA
    // 6 decimal-places ke saath print honge (jaise "0.514412" na ki "0.5144")
    for (int c = 0; c < k; c++)
    {
        cout << c << ":";
        for (int j = 0; j < d; j++)
            cout << " " << ans.center[c][j];
        cout << "\n";
    }
    // DRY RUN OUTPUT (km_01.txt): "0: 0.514412 0.480000\n1: 10.470000 10.475152\n2: ..."

    cout << "WCSS: " << ans.wcss << "\n";
    cout << "Iterations: " << ans.iterations << "\n";
    cout << "Converged: " << (ans.converged ? "true" : "false") << "\n";
    cout << "Execution time: " << time << " ms\n";
    // DRY RUN OUTPUT (km_01.txt, maine khud verify kiya):
    //   WCSS: 16.616687   Iterations: 2   Converged: true
}

void runFastMapFile(const string& file)
{
    ifstream in(file);
    if (!in)
    {
        cout << "Could not open file.\n";
        return;
    }

    int n, k;
    in >> n >> k;
    // FILE FORMAT: pehli line = "N K" (kitne objects, kitni target-dimensions)
    // DRY RUN (fm_01.txt): n=10, k=2

    vector<vector<double>> dist(n, vector<double>(n));
    // dist ek N×N SQUARE matrix hai (har object se har DOOSRE object tak ki
    // distance) — isliye "vector<vector<double>>" size N×N, na ki N×D
    // (kmeans wale "points" se DIFFERENT SHAPE hai, kyunki yaha humein
    //  ASLI coordinates nahi, sirf PAIRWISE distances di gayi hai)

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            in >> dist[i][j];
    // DRY RUN (fm_01.txt): dist[0] = [0,1,2,3,4,5,6,7,8,9], dist[1]=[1,0,1,2,...], etc.

    // ---------- ASLI ALGORITHM CHALAO, TIME MEASURE KARTE HUE ----------
    auto start = chrono::high_resolution_clock::now();
    FastMapResult ans = runFastMap(dist, k);
    // NOTE: "dist" yaha BY VALUE pass ho raha hai runFastMap() mein (fastmap.h
    // mein "vector<vector<double>> dist" signature hai, "const&" nahi) —
    // matlab poori N×N matrix ki EK COPY runFastMap() ke andar BANTI hai.
    // Chhote N (jaise N=10) ke liye koi farak nahi padta, lekin N=10000
    // (fm_04 test) ke liye ye EXTRA 800MB jaisi COPY create karta hai —
    // dekh chuke ho fastmap.h ke IMPROVEMENT note mein.
    auto stop = chrono::high_resolution_clock::now();

    double time = chrono::duration<double, milli>(stop - start).count();

    // ---------- OUTPUT PRINT KARO ----------
    cout << "\nAlgorithm: FastMap\n";
    cout << "Target dimensions: " << k << "\n";
    cout << "Pivots per dimension:\n";
    for (int i = 0; i < (int)ans.pivots.size(); i++)
        cout << "Dim " << i + 1 << ": "
             << ans.pivots[i].first << " "
             << ans.pivots[i].second << "\n";
    // DRY RUN OUTPUT (fm_01.txt): "Dim 1: 9 0\nDim 2: 0 0\n"
    // NOTE: `ans.pivots.size()` k(=2) se KAM bhi ho sakta hai agar algorithm
    // beech mein hi `break` kar gaya ho (jaisa upar dry-run mein hua nahi,
    // par ho sakta tha agar ab<=0 EARLIER dimension mein hi mil jaata)

    cout << "Object coordinates:\n";
    cout << fixed << setprecision(6);
    for (int i = 0; i < n; i++)
    {
        cout << i << ":";
        for (int j = 0; j < k; j++)
            cout << " " << ans.coord[i][j];
        cout << "\n";
    }
    // DRY RUN OUTPUT: "0: 9.000000 0.000000\n1: 8.000000 0.000000\n...9: 0.000000 0.000000\n"

    cout << "Execution time: " << time << " ms\n";
}

int main(int argc, char* argv[])
{
    if (argc != 3)
        // exactly 2 arguments chahiye: algorithm-choice aur filename
        // (jaise <exe> kmeans tests/km_01.txt)
    {
        cout << "Usage: assignment4_buddy.exe kmeans/fastmap testfile\n";
        return 0;
        // NOTE: usage-error par bhi `return 0` hai (na ki `return 1`) —
        // matlab shell/scripts ke liye ye "success" jaisa treat hoga chahe
        // command GALAT ho. IMPROVEMENT: `return 1` karna zyada standard practice hai.
    }

    string type = argv[1];     // "kmeans" ya "fastmap"
    string file = argv[2];      // test-file ka path

    if (type == "kmeans")
        runKMeansFile(file);
    else if (type == "fastmap")
        runFastMapFile(file);
    else
        cout << "Use kmeans or fastmap.\n";

    return 0;
}
