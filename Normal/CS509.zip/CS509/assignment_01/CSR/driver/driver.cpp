#include <iostream>
#include <fstream>
#include <vector>

#include "../src/csr.h"

using namespace std;

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        cout << "Test file not given." << endl;
        return 1;
    }

    string fileName = argv[1];
    ifstream inputFile(fileName);

    if (!inputFile)
    {
        cout << "File could not be opened." << endl;
        return 1;
    }

    int vertices, edges;
    inputFile >> vertices >> edges; // input 4 5 hai to 4- vertice 5 - edges

    vector<vector<pair<int, int>>> graph(vertices);

    for (int i = 0; i < vertices; i++) // har vertices ko read karega
    {
        int source, degree;   
        inputFile >> source >> degree;// vertex 0 ki kitni degree hai i.e kitne neightbour hai

        for (int j = 0; j < degree; j++)  // 2 neighbour hai to 2 baar loop chalao
        {
            int destination, weight;
            inputFile >> destination >> weight; // tar pahlya neighbour cha destination kya aani weight kay
            // second loop madhe dusrya neighbour cha destination and weight kay
            graph[source].push_back({destination, weight});
            //graph[0] = {(1,5), (2,10)}, tar adjancey list banli ki 0-1 weight5 0-2 weight 10
        }
    }

    inputFile.close();

    csrgraph csr = convert_to_csr(graph);  // csr mein convert kiya ye adjancey list input mein dekar

    cout << "\nRow Pointer\n";
    for (int x : csr.rowPtr)    // csr mein rowptr aaya tha use print kiya
        cout << x << " ";

    cout << "\n\nColumn Index\n";
    for (int x : csr.colIdx)  // csr mein rowptr aaya tha use print kiya
        cout << x << " ";

    cout << "\n\nValues\n";
    for (int x : csr.values)    // // csr mein rowptr aaya tha use print kiya
        cout << x << " ";

    cout << endl;

    return 0;
}
