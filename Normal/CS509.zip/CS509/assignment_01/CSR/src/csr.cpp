#include "csr.h"
// colIdx -> isme neighbour store honge
// values -> isme edges ke weight store honge
// rowPtr -> kisi vertex ke neighbors colIdx mein kahan se start aur kahan end hote hain
csrgraph convert_to_csr(const vector<vector<pair<int, int>>>& adjacencyList)
{
    csrgraph csr;   // csrgraph ka object banaya

    csr.rowPtr.push_back(0); // csr ka rowPtr 0 se start hota hai so pushed 0


    for (int i = 0; i < adjacencyList.size(); i++)// x vertex ke
    {
        for (int j = 0; j < adjacencyList[i].size(); j++) // jitne neighbour hai
        {
            csr.colIdx.push_back(adjacencyList[i][j].first);// pahla int i.e destination/ neighbour
            csr.values.push_back(adjacencyList[i][j].second);// dusra int i.e weight 
        }

        csr.rowPtr.push_back(csr.colIdx.size());
    }

    return csr;
}