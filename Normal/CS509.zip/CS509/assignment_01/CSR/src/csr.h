#ifndef CSR_H
#define CSR_H

#include <vector>

using namespace std;

struct csrgraph
{
    vector<int> rowPtr;
    vector<int> colIdx;
    vector<int> values;
};


//Mujhe adjacency list do, main usko CSR mein convert karke csrgraph return karunga.
csrgraph convert_to_csr(
    const vector<vector<pair<int, int>>>& adjacencyList
    // do do int ek- destination ke liye dusra - weight ke liye
    //(destination,weight)
);

#endif