Assignment 3 - MST

This folder contains the initial individual MST implementation.

Files:
driver/driver.cpp
src/kruskal.h
src/kruskal.cpp
src/prim.h
src/prim.cpp
tests/mst_10.txt
tests/mst_100.txt
tests/mst_10000.txt
tests/mst_50000.txt
tests/mst_100000.txt

The implementation reuses the CSR module already present in:
assignment_01/CSR/src/csr.h
assignment_01/CSR/src/csr.cpp

Place assignment_03 directly inside the same CS509 root folder as assignment_01.

The first driver test is mst_10.txt. We should verify this small case before changing the driver for the larger test cases.
