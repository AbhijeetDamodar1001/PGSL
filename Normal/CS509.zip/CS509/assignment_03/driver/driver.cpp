#include <iostream>
#include <fstream>
#include <vector>
#include <utility>
#include <chrono>

#include "../../assignment_01/CSR/src/csr.h"
#include "../src/kruskal.h"
#include "../src/prim.h"

using namespace std;
using namespace chrono;

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        cout << "Algorithm or test file not given." << endl;
        return 1;
    }

    string choice = argv[1];
    string testFile = argv[2];

    ifstream input(testFile);

    if (!input)
    {
        cout << "Could not open MST input file." << endl;
        return 1;
    }

    int vertices, edges;
    input >> vertices >> edges; // 6 8 as input

    vector<vector<pair<int, int>>> graph(vertices); // aisa gtPH BANEGA graph[0] = {{1,5}, {2,3}}

    for (int i = 0; i < vertices; i++) // HAR VERTEX KI INFO READ HOGI
    {
        int vertex, degree;
        input >> vertex >> degree;  //2 3 0 5 1 2 4 7 toh: vertex = 2 degree = 3

        for (int j = 0; j < degree; j++)
        {
            int next, weight;
            input >> next >> weight;
            graph[vertex].push_back({next, weight});
            /*2 3 0 5 1 2 4 7

                Then:

                next = 0, weight = 5
                next = 1, weight = 2
                next = 4, weight = 7

                Graph:

                graph[2] =
                {
                    {0,5},
                    {1,2},
                    {4,7}
}*/
        }
    }

    input.close();

    csrgraph csr = convert_to_csr(graph);

    if (choice == "kruskal")
    {
        vector<MSTEdge> mstEdges;

        auto start = high_resolution_clock::now();

        int totalWeight = kruskalMST(csr, mstEdges);

        auto stop = high_resolution_clock::now();

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nKruskal MST" << endl;

        for (const auto& e : mstEdges)
            cout << e.from << " " << e.to << " " << e.weight << endl;

        cout << "Total MST weight: " << totalWeight << endl;
        cout << "Execution time: "
             << timeTaken.count() / 1000.0
             << " ms" << endl;
    }
    else if (choice == "prim")
    {
        vector<MSTEdge> mstEdges;

        auto start = high_resolution_clock::now();

        int totalWeight = primMST(csr, mstEdges);

        auto stop = high_resolution_clock::now();

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nPrim MST" << endl;

        for (const auto& e : mstEdges)
            cout << e.from << " " << e.to << " " << e.weight << endl;

        cout << "Total MST weight: " << totalWeight << endl;
        cout << "Execution time: "
             << timeTaken.count() / 1000.0
             << " ms" << endl;
    }
    else
    {
        cout << "Invalid algorithm." << endl;
        return 1;
    }

    return 0;
}
