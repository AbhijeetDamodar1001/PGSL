#include "kruskal.h"
#include <algorithm>

int findParent(vector<int>& parent, int x)
{
    if (parent[x] == x)
        return x;

    parent[x] = findParent(parent, parent[x]);
    return parent[x];
}

bool compareEdges(const MSTEdge& a, const MSTEdge& b)
{ 
    /* /*Do edges mein se kaunsi edge pehle aani chahiye batana.

Example:

a.weight = 3
b.weight = 7

Then:

3 < 7

true.

Isliye 3 wali edge pehle.

Ye sort() ko diya jayega.*/*/
    return a.weight < b.weight;
}

int kruskalMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst
)
{
    int vertices = graph.rowPtr.size() - 1; // CSR mein aisa tha rowPtr size = V + 1
    vector<MSTEdge> allEdges; /*Ye temporary vector hai.
   Ismein graph ki saari edges store hongi. Kyun?
 Because Kruskal ko: all edges ko ek saath weight ke according sort karna hai.*/
    

    for (int u = 0; u < vertices; u++)  // har vertices ko dekhega
    {
        for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++) // ye u ke saare neighbour traverse kar rha HAI
        {
            int v = graph.colIdx[i];// NEIGHBOUR
            int w = graph.values[i];// WEIGHT

            if (u < v)
                allEdges.push_back({u, v, w});
                /*Kyuki graph undirected hai.

CSR mein edge:

0 --5-- 1

usually dono directions mein stored hogi:

0 → 1 = 5
1 → 0 = 5

Agar dono ko allEdges mein daal diya toh:

{0,1,5}
{1,0,5}

same edge do baar aa jayegi.

Isliye:

u < v

se sirf ek direction rakhte hain.

Example:

u=0, v=1
0 < 1 → YES

store.

Then:

u=1, v=0
1 < 0 → NO

skip.

Shortcut:

u < v = undirected edge ko duplicate hone se bachana.*/
        }
    }

    sort(allEdges.begin(), allEdges.end(), compareEdges);
    /* Krusskal sorting karega edges weight ki 
Before:
0-2 = 8
0-1 = 3
1-3 = 1
2-3 = 5

After:
1-3 = 1
0-1 = 3
2-3 = 5
0-2 = 8*/

    vector<int> parent(vertices); //Har vertex ka parent track karega.
    vector<int> rank(vertices, 0); //Trees ki height/rough size ko manage karne mein help karta hai.

    for (int i = 0; i < vertices; i++)
        parent[i] = i;
        /*Initially:

parent[0] = 0
parent[1] = 1
parent[2] = 2
parent[3] = 3

Diagram:

0    1    2    3*/

    int totalWeight = 0;  // Mst ka weight yaha add hoga

    for (int i = 0; i < allEdges.size(); i++)// sorted edge ko one by one access karega
    {
        int a = findParent(parent, allEdges[i].from);
        int b = findParent(parent, allEdges[i].to);
        /*Suppose current edge:

            2 ----5---- 3

            Toh:

            a = root of 2
            b = root of 3*/

        if (a != b)// dono agar different component mei hai to edge lene se cycle nhi banegi
        {
            mst.push_back(allEdges[i]); // to current adge MST/Answer mein dal di
            totalWeight += allEdges[i].weight;// aur total weight mein usko add kardiya

            if (rank[a] < rank[b])
                parent[a] = b; // a ko b ke under attach karo
            else if (rank[a] > rank[b])
                parent[b] = a; // b ko a ke under attach karo
            else   // agar same component mein hai to cycle banegi
            {
                parent[b] = a;
                rank[a]++;
            }

            if (mst.size() == vertices - 1)// MST mein jaise hi V-1 edges bane to break kardo 
                break;
        }
    }

    return totalWeight;  // MST ka total weight return kardo
}
