#ifndef KRUSKAL_H
#define KRUSKAL_H

#include <vector>
#include "../../assignment_01/CSR/src/csr.h"

using namespace std;

struct MSTEdge
{
    /*from = 0
      to = 1
      weight = 5

means:
0 ----5----> 1*/
    int from;
    int to;
    int weight;
};

int kruskalMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst // mst mein mein final selected edges store hongi.
);

#endif
