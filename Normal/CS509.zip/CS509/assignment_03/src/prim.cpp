#include "prim.h"
#include <queue>
#include <limits>
#include <functional>

int primMST(
    const csrgraph& graph,//CSR format mein graph.
    vector<MSTEdge>& mst// final MST edges store karne ke liye vector.
)
{
    int vertices = graph.rowPtr.size() - 1;

    if (vertices == 0)// empty graph
        return 0;

    vector<int> used(vertices, 0);
    /* ye Used array batata hai ki
    Ye vertex already MST mein aa gaya hai ya nahi?
Initially:
used = [0, 0, 0, 0]
Agar 0 aur 2 select ho gaye:
used = [1, 0, 1, 0]*/
    vector<int> best(vertices, numeric_limits<int>::max());
    /*Current MST se vertex v ko connect karne ke liye abhi tak mili minimum edge ka weight.
    Initially:
    best = [∞, ∞, ∞, ∞]*/
    vector<int> parent(vertices, -1);
    /*v ko MST mein kis vertex se connect karenge?

        Example:

        parent[3] = 2

        means:

        2 ----weight---- 3

        MST mein 2-3 edge select hogi.

        Initially:

        parent = [-1,-1,-1,-1]*/

    priority_queue<
        pair<int, int>,
        vector<pair<int, int>>,
        greater<pair<int, int>>
    > pq;//pq = {weight, vertex} hum queue mein {weight,vertex} store kar rhe hai

    best[0] = 0; // vertex zero se start
    pq.push({0, 0});// queue mein starting vertx dal diya

    int totalWeight = 0;

    while (!pq.empty())
    {
        int weight = pq.top().first;
        int u = pq.top().second;
        pq.pop();
        /*Suppose pq.top() = {4, 2}

            Then:

            weight = 4
            u = 2

            Because:

            .first  → weight
            .second → vertex

            Then:

            pq.pop();

            usse queue se remove kar diya.*/

        if (used[u])
            continue;

        used[u] = 1;// matlab vertex already mst mein aa chuka hai

        if (parent[u] != -1)
        {
            mst.push_back({parent[u], u, weight});
            totalWeight += weight;
        }

        for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++)
        {
            int v = graph.colIdx[i];
            int w = graph.values[i];

            if (!used[v] && w < best[v])
            {
                best[v] = w;
                parent[v] = u;
                pq.push({w, v});
            }
        }
    }

    return totalWeight;
}

/*Ab actual CSR traversal 🔥
for (
    int i = graph.rowPtr[u];
    i < graph.rowPtr[u + 1];
    i++
)

Ye line u ke saare neighbours traverse kar rahi hai.

Suppose:

rowPtr[u] = 5
rowPtr[u+1] = 8

Toh:

i = 5
6
7

teen neighbours hain.

18. Neighbour aur weight nikalo
int v = graph.colIdx[i];
int w = graph.values[i];

CSR:

colIdx → neighbour
values → edge weight

So:

v = neighbour
w = edge weight
19. Prim ki MOST IMPORTANT condition 🔥🔥
if (!used[v] && w < best[v])

Isko break kar:

First:
!used[v]

Neighbour already MST mein nahi hona chahiye.

Second:
w < best[v]

Current edge previous best edge se cheaper honi chahiye.

Dono true:
Current edge is a better way to connect v.
20. best[v] update
best[v] = w;

Maan:

best[3] = 10

Aur current edge:

u --4-- 3

Toh:

4 < 10

So:

best[3] = 4

Ab 3 ko connect karne ka best known cost 4 hai.

21. Parent update
parent[v] = u;

Agar current edge:

2 ----4---- 3

aur ye 3 ke liye best edge hai:

parent[3] = 2

Later jab vertex 3 select hoga:

parent[3] → 3

edge MST mein add hogi.

22. Priority queue mein daalo
pq.push({w, v});

Example:

w = 4
v = 3

then:

{4,3}

PQ mein.

Ab queue minimum weight ke according next vertex choose karegi.

23. End
return totalWeight;*/
