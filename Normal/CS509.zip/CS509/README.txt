g++ wrapper.cpp -o wrapper.exe
 ./wrapper.exe           