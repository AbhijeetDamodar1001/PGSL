#include "floydwarshall.h"

using namespace std;

/* ============================================================================
   DRY RUN EXAMPLE (fw_10.txt, 5x5 distance matrix, "INF" = 1000000000):

   START distance matrix:
        0    6  INF    7  INF
      INF    0    5    8   -4
      INF   -2    0  INF  INF
      INF  INF   -3    0    9
        2  INF    7  INF    0

   IDEA: teen nested loops (k, i, j) — "k" ek "intermediate/via" vertex hai.
   Har (i,j) pair ke liye check karo: "kya i->k->j jaana i->j (direct) se
   SASTA (chhota) hai?" Agar haan, to distance[i][j] ko us naye (i->k->j)
   route se update kardo. k=0,1,2,3,4 sab try karke, aakhir mein HAR (i,j)
   ka best/shortest distance mil jaata hai (chahe kitne bhi vertices se hoke
   guzarna pade).

   ---- TRACE for k=0 (sirf ek k ka example — poora 5x5x5=125-cell trace
        yahan likhna bahut lamba hoga, isi pattern se baaki khud kar sakte ho) ----

   k=0 ka matlab: "kya kisi i se j jaate waqt VERTEX-0 se hoke jaana faayde ka hai?"

   i=1 (dist[1][0]=INF)  -> skip (vertex 0 tak pahuchna hi possible nahi hai vertex1 se)
   i=2 (dist[2][0]=INF)  -> skip
   i=3 (dist[3][0]=INF)  -> skip
   i=4 (dist[4][0]=2, valid!):
       j=1: dist[4][0]+dist[0][1] = 2+6 = 8  <  dist[4][1](=INF) -> UPDATE dist[4][1]=8
       j=3: dist[4][0]+dist[0][3] = 2+7 = 9  <  dist[4][3](=INF) -> UPDATE dist[4][3]=9
       (j=0 khud hi hai, j=2/j=4 already INF via vertex0 so no improvement)

   AFTER k=0, Row 4 change ho gayi: [2, 8, 7, 9, 0]   (pehle [2,INF,7,INF,0] thi)
   Baaki rows is baar unchanged rahi (kyunki unka dist[i][0] abhi bhi INF tha).

   ... (isi tarah k=1,2,3,4 bhi chalte hai, har baar "via vertex k" better path
   dhoondte hai) ...

   FINAL RESULT (maine khud compile+run karke verify kiya hai):
        0   2   4   7  -2
       -2   0   2   5  -4
       -4  -2   0   3  -6
       -7  -5  -3   0  -9
        2   4   6   9   0
   ============================================================================ */

void floydWarshall(
    vector<vector<int>>& distance,
    bool& negativeCycle
)
{
    int vertices = distance.size();   // matrix NxN hai, to vertices = N (rows ki ginti)

    negativeCycle = false;

    // Try every vertex as an intermediate vertex
    for (int k = 0; k < vertices; k++)      // k = "via" vertex (in sab se hoke jaane ki koshish karo)
    {
        for (int i = 0; i < vertices; i++)   // i = source
        {
            for (int j = 0; j < vertices; j++)   // j = destination
            {
                if (distance[i][k] != 1000000000 &&
                    distance[k][j] != 1000000000)
                    // agar i->k aur k->j dono paths EXIST karte hai (INF nahi hai)
                    // tabhi hi "i->k->j" ek valid path ban sakta hai, warna
                    // 1000000000 + 1000000000 jaisa overflow/garbage aa sakta hai
                {
                    if (distance[i][k] + distance[k][j] < distance[i][j])
                        // agar via-k jaana DIRECT i->j se sasta hai
                    {
                        distance[i][j] =
                            distance[i][k] + distance[k][j];
                            // to best distance update kardo
                    }
                }
            }
        }
    }
    // 3 nested loops = O(V^3) time complexity — ye Floyd-Warshall ki
    // well-known complexity hai, chhote/medium graphs (jaise 100-500
    // vertices) ke liye theek hai, lekin bahut bade graphs ke liye slow ho jaata.

    // Check diagonal for a negative cycle
    // (agar koi vertex i khud APNE AAP tak wapas aane mein NEGATIVE distance
    //  paata hai, matlab wahan koi negative-weight cycle hai — normally
    //  distance[i][i] hamesha 0 hi hona chahiye, kabhi negative nahi)
    for (int i = 0; i < vertices; i++)
    {
        if (distance[i][i] < 0)
        {
            negativeCycle = true;
            break;   // ek hi negative cycle mil jaaye to kaafi hai batane ke liye
        }
    }
}
