#ifndef FLOYDWARSHALL_H
#define FLOYDWARSHALL_H

#include <vector>

using namespace std;

// Floyd-Warshall: ALL-PAIRS shortest path algorithm.
// (Bellman-Ford ek hi source se sabtak shortest-path deta hai, Floyd-Warshall
//  EK HI BAAR mein HAR vertex-pair (i,j) ke beech shortest-path nikal deta hai)
//
// distance: INPUT/OUTPUT parameter -> ek VxV matrix jisme distance[i][j] = i se j ka
//           direct edge-weight (ya 1000000000 agar direct edge nahi hai/"INF").
//           Function ISI matrix ko IN-PLACE modify karke shortest-distances bhar deta hai.
// negativeCycle: OUTPUT -> agar koi negative cycle mili to true set hota hai
void floydWarshall(
    vector<vector<int>>& distance,
    bool& negativeCycle
);

#endif
