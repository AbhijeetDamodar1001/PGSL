#include "bellmanford.h"

#include <vector>    // Input file driver.cpp mein dali hai
#include <climits>   // INT_MAX ke liye chahiye ("infinity" represent karne ke liye use hota hai)

using namespace std;

/* ============================================================================
   DRY RUN EXAMPLE (bf_10.txt se, 5 vertices, source=0):
   Edges (directed): 0->1(w=6), 0->3(w=7)
                      1->2(w=5), 1->3(w=8), 1->4(w=-4)
                      2->1(w=-2)
                      3->2(w=-3), 3->4(w=9)
                      4->0(w=2), 4->2(w=7)

   (NOTE: maine ye khud compile+run karke verify kiya. Original bf_10.txt file
    mein "//" inline comments the jinhone parsing tod di thi -> uska bug README
    mein detail se explain kiya hai. Ye trace CLEAN/corrected data par hai.)

   distance[] START = [0, INF, INF, INF, INF]   (source=0 -> distance[0]=0)

   ---- ITERATION 1 (i=0) ----
   u=0: 0+6=6 < INF -> distance[1]=6 | 0+7=7 < INF -> distance[3]=7
   u=1: 6+5=11 < INF -> distance[2]=11 | 6+8=14 not<7(skip) | 6-4=2 < INF -> distance[4]=2
   u=2: 11-2=9 not < 6 (skip)
   u=3: 7-3=4 < 11 -> distance[2]=4 (UPDATE!) | 7+9=16 not < 2 (skip)
   u=4: 2+2=4 not < 0 (skip) | 2+7=9 not < 4 (skip)
   -> distance = [0, 6, 4, 7, 2]     updated=true

   ---- ITERATION 2 (i=1) ----
   u=0: 0+6=6 not<6 | 0+7=7 not<7
   u=1: 6+5=11 not<4 | 6+8=14 not<7 | 6-4=2 not<2
   u=2: 4-2=2 < 6 -> distance[1]=2  (UPDATE!)
   u=3: 7-3=4 not<4 | 7+9=16 not<2
   u=4: 2+2=4 not<0 | 2+7=9 not<4
   -> distance = [0, 2, 4, 7, 2]     updated=true

   ---- ITERATION 3 (i=2) ----
   u=0: 0+6=6 not<2 | 0+7=7 not<7
   u=1: 2+5=7 not<4 | 2+8=10 not<7 | 2-4=-2 < 2 -> distance[4]=-2  (UPDATE!)
   u=2: 4-2=2 not<2
   u=3: 7-3=4 not<4 | 7+9=16 not<-2
   u=4: -2+2=0 not<0 | -2+7=5 not<4
   -> distance = [0, 2, 4, 7, -2]    updated=true

   ---- ITERATION 4 (i=3, ye 5-1=4 hi iterations hoti hai) ----
   koi bhi edge relax nahi hoti (sab check "not <" nikalte hai) -> updated=false
   -> distance = [0, 2, 4, 7, -2]    (SAME rehta hai, loop yahin "break" bhi kar sakta tha)

   FINAL DISTANCES: 0->0, 1->2, 2->4, 3->7, 4->-2
   (Maine khud compile+run kiya tha, EXACT yehi output aaya tha!)

   Negative cycle check (aakhri baar sab edges phir se try karo):
   koi bhi edge relax nahi hoti -> negativeCycle = false
   ============================================================================ */

vector<int> bellmanFord(const csrgraph &graph,
                        int vertices,
                        int source,
                        bool &negativeCycle)
{
    // Distance array
    vector<int> distance(vertices, INT_MAX);   // for eg : 5 vertices sabmein infinite dal diya

    // Source vertex distance
    distance[source] = 0;  // source ka distance zero kiya

    // Initially assume no negative cycle
    negativeCycle = false;

    // Relax all edges (V-1) times
    // (Ye Bellman-Ford ka CORE THEOREM hai: kisi bhi shortest-path mein max V-1 edges
    //  ho sakte hai (agar negative cycle na ho), isliye V-1 baar saari edges "relax"
    //  karne se guaranteed shortest-distances mil jaate hai)
    for(int i = 0; i < vertices - 1; i++)
    {
        bool updated = false;   // is baar (is iteration mein) koi distance improve hui kya, track karo

        for(int u = 0; u < vertices; u++)      // har vertex u ko source maan kar
        {
            // CSR format mein vertex u ke saare neighbours rowPtr[u] se rowPtr[u+1] tak milte hai
            for(int j = graph.rowPtr[u]; j < graph.rowPtr[u + 1]; j++)
            {
                int v = graph.colIdx[j];         // u ka neighbour (destination) v
                int weight = graph.values[j];     // edge (u->v) ka weight

                if(distance[u] != INT_MAX &&     // Agar 1-4 ka weight 6 hai 
                    // aur 1-2 -> 4 , 2->4 ka -2 to is path par jao
                    // (u abhi tak "unreachable" (INT_MAX) na ho, tabhi aage badhna chahiye,
                    //  warna INT_MAX + weight overflow ho sakta hai!)
                   distance[u] + weight < distance[v])
                    // "RELAXATION STEP": agar u ke through v tak jaana, ab tak ke best
                    // distance[v] se BEHTAR (chhota) hai, to update kardo
                {
                    distance[v] = distance[u] + weight;
                    updated = true;
                }
            }
        }

        // Stop early if no update happened
        // (agar ek poori iteration mein KOI bhi distance improve nahi hui,
        //  matlab convergence ho chuki hai — baaki iterations bekar hai, break kardo)
        if(!updated)
        {
            break;
        }
    }

    // Check for negative weight cycle
    // (V-1 iterations ke baad agar AB BHI koi edge relax ho sakti hai,
    //  matlab graph mein negative-weight cycle hai — kyunki normal graph mein
    //  V-1 iterations ke baad koi improvement possible nahi hoti)
    for(int u = 0; u < vertices; u++)
    {
        for(int j = graph.rowPtr[u]; j < graph.rowPtr[u + 1]; j++)
        {
            int v = graph.colIdx[j];
            int weight = graph.values[j];

            if(distance[u] != INT_MAX &&
               distance[u] + weight < distance[v])
            {
                negativeCycle = true;
                return distance;   // negative cycle mil gayi, turant return kardo
                // NOTE: is case mein distance[] array PARTIALLY/UNRELIABLE hota hai
                // (kyunki negative cycle wale vertices ka "shortest" distance
                //  well-defined hi nahi hota — infinitely chhota ho sakta hai)
            }
        }
    }

    return distance;
}
