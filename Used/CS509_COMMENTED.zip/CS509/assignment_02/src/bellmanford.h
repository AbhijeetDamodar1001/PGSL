#ifndef BELLMANFORD_H
#define BELLMANFORD_H

#include <vector>
#include "../../assignment_01/CSR/src/csr.h"
// NOTE: assignment_01 ka CSR module yahan REUSE ho raha hai (relative path se
// include kiya gaya hai) — isliye README.txt mein likha tha ki assignment_02
// ko assignment_01 ke SAME root folder ke andar hi rakhna zaroori hai.

using namespace std;

// Bellman-Ford Single-Source Shortest Path algorithm.
// graph: CSR format mein diya gaya directed weighted graph (negative weights allowed hai)
// vertices: total vertices ki ginti
// source: kis vertex se shortest-path nikalna hai
// negativeCycle: OUTPUT parameter -> agar graph mein negative-weight cycle mili
//                to ye true set ho jayega (aur distances unreliable honge)
// Return: har vertex ka shortest distance (source se), agar reachable nahi to INT_MAX
vector<int> bellmanFord(
    const csrgraph& graph,
    int vertices,
    int source,
    bool& negativeCycle
);

#endif
