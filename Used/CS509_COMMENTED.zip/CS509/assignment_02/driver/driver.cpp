#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <chrono>       // execution-time measurement ke liye
#include <climits>      // INT_MAX ke liye

#include "../src/bellmanford.h"
#include "../src/floydwarshall.h"
#include "../../assignment_01/CSR/src/csr.h"   // CSR module yahan bhi reuse ho raha hai

using namespace std;
using namespace chrono;

const int INF = 1000000000;   // "infinity" ko represent karne ke liye ek bada number
// (INT_MAX use nahi kiya kyunki INT_MAX+INT_MAX Floyd-Warshall mein overflow karta,
//  isliye ek "bada lekin safe-to-add" number chuna gaya)

/* ============================================================================
   YE DRIVER EK "SWITCH-BOARD" HAI: command-line ke pehle argument ("bf" ya "fw")
   ke hisaab se decide karta hai ki Bellman-Ford chalana hai ya Floyd-Warshall.
   Usage:  ./driver bf  bf_10.txt      (Bellman-Ford)
           ./driver fw  fw_10.txt      (Floyd-Warshall)
   ============================================================================ */

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        // kam se kam 2 arguments chahiye: algorithm-choice aur filename
        cout << "Algorithm or test file not given." << endl;
        return 1;
    }

    string choice = argv[1];      // "bf" ya "fw"
    string fileName = argv[2];    // test-file ka naam

    if (choice == "bf")
    {
        /* ---------------------- BELLMAN-FORD BRANCH ---------------------- */
        ifstream inputFile(fileName);

        if (!inputFile)
        {
            cout << "Could not open Bellman-Ford input file." << endl;
            return 1;
        }

        int vertices, edges;
        inputFile >> vertices >> edges;
        // DRY RUN (bf_10.txt): vertices=5, edges=10

        vector<vector<pair<int, int>>> adjacencyList(vertices);

        for (int i = 0; i < vertices; i++)
        {
            int vertex, degree;
            inputFile >> vertex >> degree;
            // DRY RUN (i=0): vertex=0, degree=2

            for (int j = 0; j < degree; j++)
            {
                int neighbour, weight;
                inputFile >> neighbour >> weight;
                // DRY RUN: neighbour=1, weight=6 (pehla edge)
                adjacencyList[vertex].push_back({neighbour, weight});
            }
        }
        // ⚠️ IMPORTANT BUG NOTED (asli bf_10.txt file ke saath):
        // Maine khud compile+run kiya to bf_10.txt ka original content mein
        // HAR line ke aakhir mein "// <comment>" likha hua tha (jaise "5 10 // 5 vertices...").
        // C++ ka ifstream ">>" operator IN COMMENTS ko IGNORE NAHI karta — wo
        // "//" ko bhi ek TOKEN maan kar parse karne ki koshish karta hai, jisse
        // number-parsing FAIL ho jaati hai aur poori file "misaligned" padhi jaati hai.
        // Result: sab distances galat/INF aa jaate hai! Maine comments hata kar
        // (clean file bana kar) dobara test kiya to sahi answer mila — neeche dekho.
        // -> IMPROVEMENT: test-data files mein "//" jaise comments NAHI hone chahiye,
        //    ya phir driver ko file padhte waqt comments strip karne chahiye.

        string word;      // ye "SOURCE" wala literal keyword padhega
        int source;
        inputFile >> word >> source;
        // DRY RUN: word="SOURCE", source=0
        inputFile.close();

        csrgraph graph = convert_to_csr(adjacencyList);
        // adjacency-list ko CSR mein convert kiya (assignment_01 ka function reuse)

        bool negativeCycle = false;

        auto start = high_resolution_clock::now();   // stopwatch start

        vector<int> distance =
            bellmanFord(graph, vertices, source, negativeCycle);

        auto stop = high_resolution_clock::now();     // stopwatch stop

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nAlgorithm: Bellman-Ford" << endl;
        cout << "Source: " << source << endl;

        if (negativeCycle)
        {
            cout << "Negative cycle: true" << endl;
        }
        else
        {
            cout << "\nVertex Distance" << endl;

            for (int i = 0; i < vertices; i++)
            {
                cout << i << " ";

                if (distance[i] == INT_MAX)
                    cout << "INF";      // unreachable vertex ke liye "INF" print karo
                else
                    cout << distance[i];

                cout << endl;
            }
            // DRY RUN OUTPUT (CLEAN bf_10.txt ke saath, jo maine khud test kiya):
            //   0 0
            //   1 2
            //   2 4
            //   3 7
            //   4 -2

            cout << "Negative cycle: none" << endl;
        }

        cout << "Execution time: "
             << timeTaken.count()
             << " microseconds" << endl;
    }
    else if (choice == "fw")
    {
        /* ---------------------- FLOYD-WARSHALL BRANCH ---------------------- */
        ifstream inputFile(fileName);

        if (!inputFile)
        {
            cout << "Could not open Floyd-Warshall input file." << endl;
            return 1;
        }

        int vertices;
        inputFile >> vertices;
        // DRY RUN (fw_10.txt): vertices = 5

        vector<vector<int>> distance(
            vertices, vector<int>(vertices));
        // 5x5 matrix banaya (initially garbage/0, neeche bhara jayega)

        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                string value;
                inputFile >> value;
                // file mein "INF" text bhi ho sakta hai isliye pehle STRING mein padha

                if (value == "INF")
                    distance[i][j] = INF;    // "INF" text mila -> 1000000000 daal do
                else
                    distance[i][j] = stoi(value);   // warna string ko integer mein convert karo
                // DRY RUN (i=0,j=0): value="0" -> distance[0][0]=0
                // DRY RUN (i=0,j=2): value="INF" -> distance[0][2]=1000000000
            }
        }

        inputFile.close();

        bool negativeCycle = false;

        auto start = high_resolution_clock::now();

        floydWarshall(distance, negativeCycle);
        // NOTE: distance matrix ISI function ke andar IN-PLACE modify ho jaata hai

        auto stop = high_resolution_clock::now();

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nAlgorithm: Floyd-Warshall" << endl;

        if (negativeCycle)
        {
            cout << "Negative cycle: true" << endl;
        }
        else
        {
            cout << "\nDistance matrix:" << endl;

            for (int i = 0; i < vertices; i++)
            {
                for (int j = 0; j < vertices; j++)
                {
                    if (distance[i][j] == INF)
                        cout << "INF ";
                    else
                        cout << distance[i][j] << " ";
                }
                cout << endl;
            }
            // DRY RUN OUTPUT (maine khud verify kiya):
            //   0   2   4   7  -2
            //  -2   0   2   5  -4
            //  -4  -2   0   3  -6
            //  -7  -5  -3   0  -9
            //   2   4   6   9   0

            cout << "Negative cycle: none" << endl;
        }

        cout << "Execution time: "
             << timeTaken.count()
             << " microseconds" << endl;
    }
    else
    {
        // "bf" ya "fw" ke alawa kuch aur diya gaya (jaise typo "BF" capital mein)
        cout << "Invalid algorithm." << endl;
        return 1;
    }

    return 0;
}
