#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>

#include "../src/coloring.h"
#include "../src/pagerank.h"

using namespace std;
using namespace chrono;

/* ============================================================================
   NOTE: Ye driver poore project mein SABSE ZYADA "DEFENSIVE" (safe) hai —
   yaha HAR file-read ke baad validation check hai (`if (!(file >> ...) || ...)`),
   jabki baaki assignments (GEMM, CSR, BF/FW, MST) ke drivers mein aisi
   validation KAAFI KAM hai. Ye ek achha PATTERN hai jo baaki assignments
   mein bhi copy kiya jaa sakta hai (README mein isko highlight kiya hai).
   ============================================================================ */

bool readGraph(const string& fileName, vector<vector<pair<int, int>>>& graph,
               bool directed, double& damping, double& tolerance,
               int& maxIterations)
{
    ifstream file(fileName);
    if (!file)
        return false;   // file khud hi nahi khuli

    int vertices, edges;
    if (!(file >> vertices >> edges) || vertices <= 0 || edges < 0)
        return false;
        // agar padhne mein FAIL hui, YA vertices 0/negative hai, YA edges negative hai -> REJECT
        // DRY RUN (color_10.txt): vertices=10, edges=20 -> yahan tak sab theek

    graph.assign(vertices, vector<pair<int, int>>());
    // adjacency-list ko 'vertices' size ki khaali lists se bhar do

    for (int i = 0; i < vertices; i++)
    {
        int u, degree;
        if (!(file >> u >> degree) || u < 0 || u >= vertices || degree < 0)
            return false;
            // u KOI bhi valid vertex-number honi chahiye (0..vertices-1), degree negative nahi ho sakti

        for (int j = 0; j < degree; j++)
        {
            int v;
            if (!(file >> v) || v < 0 || v >= vertices)
                return false;
                // NOTE: is driver mein sirf DESTINATION (v) padha ja raha hai, WEIGHT nahi
                // (kyunki coloring/pagerank ko edge-weight ki zaroorat hi nahi hoti)

            if (!directed && u == v)
                return false;
                // UNDIRECTED graph (coloring) mein "self-loop" (u->u) allowed nahi

            graph[u].push_back({v, 1});
            // weight hamesha 1 HARDCODE kar diya (kyunki file mein weight hai hi nahi)
        }
    }

    if (directed)
        // pagerank ke liye graph "directed" hota hai, AUR is case mein file ke
        // AAKHIR mein 3 extra lines (DAMPING/TOLERANCE/MAX_ITERATIONS) bhi hoti hai
    {
        string word;
        if (!(file >> word >> damping))
            return false;
        if (word != "DAMPING" || damping <= 0.0 || damping >= 1.0)
            return false;
            // damping STRICTLY (0,1) ke beech honi chahiye (0 ya 1 valid nahi)
        // DRY RUN (pagerank_10.txt): word="DAMPING", damping=0.85 ✓

        if (!(file >> word >> tolerance) || word != "TOLERANCE" || tolerance <= 0.0)
            return false;
        // DRY RUN: word="TOLERANCE", tolerance=0.0001 ✓

        if (!(file >> word >> maxIterations) || word != "MAX_ITERATIONS" || maxIterations <= 0)
            return false;
        // DRY RUN: word="MAX_ITERATIONS", maxIterations=100 ✓
    }

    return true;   // sab kuch sahi se padh liya
}

csrgraph makeCSR(const vector<vector<pair<int, int>>>& graph)
{
    // ek chhota WRAPPER function hai jo seedha convert_to_csr() ko call karta hai
    // (shayad readability/naming-consistency ke liye banaya gaya)
    return convert_to_csr(graph);
}

int main(int argc, char* argv[])
{
    if (argc != 3)
        // NOTE: yaha "!=3" check hai (na ki "<3" jaisa baaki drivers mein),
        // matlab EXTRA arguments (jaise "color test.txt extra") bhi REJECT ho jaayenge
    {
        cout << "Usage: assignment4.exe color/pagerank testfile" << endl;
        return 1;
    }

    string choice = argv[1];      // "color" ya "pagerank"
    string fileName = argv[2];

    vector<vector<pair<int, int>>> list;
    double damping = 0.85;         // DEFAULT values (agar "color" mode ho to
    double tolerance = 0.0001;      // ye ADAPT bhi nahi hote, pagerank mode mein hi use hote hai)
    int maxIterations = 100;

    bool directed = (choice == "pagerank");
    // ⭐ IMPORTANT DESIGN CHOICE: "coloring" ke liye graph UNDIRECTED treat hota hai,
    // "pagerank" ke liye graph DIRECTED treat hota hai — isi ek boolean se
    // readGraph() ke andar dono tarah ka validation/parsing decide hota hai

    if (choice != "color" && choice != "pagerank")
    {
        cout << "Invalid algorithm." << endl;
        return 1;
    }

    if (!readGraph(fileName, list, directed, damping, tolerance, maxIterations))
    {
        cout << "Could not read input file." << endl;
        return 1;
    }

    csrgraph graph = makeCSR(list);
    int vertices = graph.rowPtr.size() - 1;

    if (choice == "color")
    {
        int colorsUsed = 0;
        auto start = high_resolution_clock::now();
        vector<int> color = greedyColoring(graph, colorsUsed);
        auto stop = high_resolution_clock::now();

        bool valid = checkColoring(graph, color);
        // yahan EXTRA STEP hai jo baaki assignments mein NAHI dikha — apna
        // hi output SELF-VERIFY karna (achhi practice hai!)
        double time = duration<double, milli>(stop - start).count();

        cout << "Algorithm: Greedy Vertex Coloring" << endl;
        cout << "Vertex colors:" << endl;
        for (int i = 0; i < vertices; i++)
            cout << i << " " << color[i] << endl;

        cout << "Colors used: " << colorsUsed << endl;
        cout << "Valid: " << (valid ? "true" : "false") << endl;
        cout << "Execution time: " << time << " ms" << endl;
        // DRY RUN OUTPUT (color_10.txt, maine khud verify kiya):
        //   colors: 0 0 / 1 1 / 2 2 / 3 0 / 4 1 / 5 2 / 6 0 / 7 1 / 8 2 / 9 3
        //   Colors used: 4
        //   Valid: true
    }
    else   // choice == "pagerank"
    {
        int iterations;
        bool converged;

        auto start = high_resolution_clock::now();
        vector<double> rank = pageRank(graph, damping, tolerance,
                                       maxIterations, iterations, converged);
        auto stop = high_resolution_clock::now();

        double time = duration<double, milli>(stop - start).count();
        double sum = 0.0;
        for (double x : rank)
            sum += x;
            // sanity-check ke liye: sab ranks ka sum HAMESHA 1.0 (ya bahut kareeb) hona chahiye

        cout << "Algorithm: PageRank" << endl;
        cout << "Damping: " << damping << endl;
        cout << "Vertex ranks:" << endl;
        for (int i = 0; i < vertices; i++)
            cout << i << " " << rank[i] << endl;

        cout << "Sum of ranks: " << sum << endl;
        cout << "Iterations: " << iterations << endl;
        cout << "Converged: " << (converged ? "true" : "false") << endl;
        cout << "Execution time: " << time << " ms" << endl;
        // DRY RUN OUTPUT (pagerank_10.txt, maine khud verify kiya):
        //   sab ranks = 0.1, Sum of ranks: 1, Iterations: 1, Converged: true
    }

    return 0;
}
