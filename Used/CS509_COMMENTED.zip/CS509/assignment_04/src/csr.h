#ifndef ASSIGNMENT4_CSR_H
#define ASSIGNMENT4_CSR_H

// Ye file khud koi naya code NAHI likhti — sirf ek "convenience wrapper" hai
// jo assignment_01 ke ASLI csr.h ko re-include kar deti hai, taaki
// assignment_04 ki files sirf "csr.h" likh ke include kar sake
// (lambe "../../assignment_01/CSR/src/csr.h" path baar-baar likhne ki
//  jagah). coloring.h aur pagerank.h dono isi ko include karte hai.
#include "../../assignment_01/CSR/src/csr.h"

#endif
