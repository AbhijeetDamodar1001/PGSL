#include "pagerank.h"
#include <cmath>   // fabs() ke liye (floating-point absolute value)

/* ============================================================================
   PAGERANK KA FORMULA (har vertex v ke liye, har iteration mein):

     rank_new[v] = (1-damping)/n                          <- "random jump" wala part
                 + damping * (dangling_rank_sum / n)        <- "dangling nodes" ka fair-share
                 + damping * SUM over u->v of (rank[u] / outdegree(u))   <- "link se aaya" hua rank

   "Dangling node" wo vertex hai jiska KOI outgoing edge NAHI hai (degree=0)
   — uska rank kahin "flow" nahi hota, isliye use sab vertices mein EQUALLY
   BAANT diya jaata hai (warna total-rank 1.0 se kam hota jaata).

   ============================================================================
   DRY RUN EXAMPLE (pagerank_10.txt, damping=0.85, tolerance=0.0001):
   Graph: har vertex v, (v+1)%10 aur (v+7)%10 ki taraf point karta hai
   (0->1,0->7 | 1->2,1->8 | 2->3,2->9 | ... | 9->0,9->6)
   Ye ek "REGULAR" graph hai: HAR vertex ka OUT-DEGREE=2 AUR IN-DEGREE=2 bhi hai!

   START: rank[i] = 1/10 = 0.1  (har vertex ke liye SAME, kyunki n=10)

   ---- ITERATION 1 ----
   dangling = 0   (koi bhi vertex ka out-degree 0 nahi hai)
   base  = (1-0.85)/10 = 0.15/10 = 0.015
   extra = 0.85 * 0 / 10 = 0
   next[v] = 0.015 (sabke liye, shuruaati value)

   Ab har u apna rank apne 2 neighbours mein baantta hai:
       part = damping * rank[u] / degree = 0.85 * 0.1 / 2 = 0.0425
   Kyunki HAR vertex ke EXACTLY 2 "incoming" edges hai (regular graph!),
   har next[v] ko 2 baar +0.0425 milta hai:
       next[v] = 0.015 + 0.0425 + 0.0425 = 0.015 + 0.085 = 0.1

   change = sum(|next[v] - rank[v]|) = sum(|0.1 - 0.1|) = 0.0
   0.0 <= tolerance(0.0001) -> CONVERGED = true, RUK JAO (sirf 1 iteration lagi!)

   FINAL: sab 10 vertices ka rank = 0.1, sum = 1.0, iterations=1, converged=true
   (Maine khud compile+run karke verify kiya — EXACT yehi output aaya.
    Ye ek "perfectly symmetric/regular" graph hone ki wajah se pehli hi
    iteration mein steady-state pahunch gaya — ye har graph ke liye NAHI
    hota, generally isse zyada iterations lagti hai.)
   ============================================================================ */

vector<double> pageRank(const csrgraph& graph, double damping,
                        double tolerance, int maxIterations,
                        int& iterations, bool& converged)
{
    int n = graph.rowPtr.size() - 1;         // total vertices
    vector<double> rank(n, 1.0 / n);          // START: har vertex ko EQUAL rank do (1/n)
    vector<double> next(n);                     // is iteration ke NAYE ranks yahan banenge

    iterations = 0;
    converged = false;

    for (int step = 0; step < maxIterations; step++)     // max "maxIterations" baar try karo
    {
        // ---------- Step 1: DANGLING nodes ka total rank nikaalo ----------
        double dangling = 0.0;

        for (int u = 0; u < n; u++)
        {
            if (graph.rowPtr[u] == graph.rowPtr[u + 1])
                // agar rowPtr[u]==rowPtr[u+1] matlab is vertex ka KOI
                // neighbour hi nahi hai (out-degree = 0, "dead end")
                dangling += rank[u];
        }
        // DRY RUN: is graph mein koi dangling node nahi, dangling=0.0

        // ---------- Step 2: base value nikaalo (random-jump + dangling-share) ----------
        double base = (1.0 - damping) / n;
        double extra = damping * dangling / n;
        // DRY RUN: base=0.015, extra=0.0

        for (int v = 0; v < n; v++)
            next[v] = base + extra;
            // sab vertices ko SHURU MEIN yehi minimum guaranteed rank milta hai
            // DRY RUN: next[all] = 0.015

        // ---------- Step 3: har vertex apna rank apne OUTGOING edges mein "flow" kare ----------
        for (int u = 0; u < n; u++)
        {
            int degree = graph.rowPtr[u + 1] - graph.rowPtr[u];   // u ka out-degree
            if (degree == 0)
                continue;    // dangling node -> uska koi neighbour nahi hai jise dena ho, skip

            double part = damping * rank[u] / degree;
            // u apna rank[u] apne SAARE (degree) neighbours mein EQUALLY baantta hai
            // DRY RUN (u=0): part = 0.85*0.1/2 = 0.0425

            for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++)
            {
                int v = graph.colIdx[i];
                next[v] += part;
                // DRY RUN: u=0 apne neighbours (1 aur 7) ko +0.0425 deta hai
            }
        }

        // ---------- Step 4: check karo ki pichli iteration se kitna CHANGE hua ----------
        double change = 0.0;
        for (int i = 0; i < n; i++)
            change += fabs(next[i] - rank[i]);
            // "L1 distance" -> total kitna farak aaya sab vertices ke rank mein milakar

        rank = next;      // naye ranks ko "current" bana do (agli iteration ke liye)
        iterations++;

        if (change <= tolerance)
            // agar change bahut CHHOTA hai (matlab values ab STABLE ho chuki hai)
        {
            converged = true;
            break;   // aur iterations karne ki zaroorat nahi, ruk jao
        }
    }

    return rank;   // DRY RUN: [0.1, 0.1, 0.1, ..., 0.1] (10 baar)
}
