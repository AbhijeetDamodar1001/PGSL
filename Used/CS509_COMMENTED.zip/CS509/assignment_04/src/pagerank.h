#ifndef PAGERANK_H
#define PAGERANK_H

#include <vector>
#include "csr.h"

using namespace std;

// PageRank: Google ka famous algorithm jo har vertex (jaise "webpage") ki
// "importance/rank" nikalta hai — jitne zyada (aur jitne important) vertices
// kisi vertex v ki taraf point karte hai, utna hi v ka rank BADA hota hai.
//
// graph: CSR format mein diya gaya DIRECTED graph
// damping: "damping factor" (usually 0.85) -> kitni probability se user
//          "link follow" karega vs random naye page par "jump" karega
// tolerance: convergence-threshold (agar iteration-to-iteration change
//            isse KAM ho jaaye, to maano converge ho gaya)
// maxIterations: kitni baar tak iterate karna hai (agar tolerance na mile to bhi rukna)
// iterations: OUTPUT -> asal mein kitni iterations lagi
// converged: OUTPUT -> converge hua ya maxIterations tak nahi hua
// Return: har vertex ka final PageRank score (sab scores ka sum = 1.0 hota hai)
vector<double> pageRank(const csrgraph& graph, double damping,
                        double tolerance, int maxIterations,
                        int& iterations, bool& converged);

#endif
