#ifndef COLORING_H
#define COLORING_H

#include <vector>
#include "csr.h"

using namespace std;

// Greedy Vertex Coloring: har vertex ko ek "color" (number) do aisa ki
// KISI BHI DO CONNECTED (neighbouring) vertices ka color SAME na ho.
// Goal: KAM SE KAM colors mein poora graph color karna (chromatic number
// exactly nikalna NP-Hard hai, isliye ye ek GREEDY approximation hai).
//
// graph: CSR format mein diya gaya undirected graph
// colorsUsed: OUTPUT -> total kitne DIFFERENT colors use hue
// Return: har vertex ka assigned color (0-indexed)
vector<int> greedyColoring(const csrgraph& graph, int& colorsUsed);

// Verify karta hai ki di gayi coloring VALID hai ya nahi
// (matlab koi bhi do connected vertices ka color same to nahi)
bool checkColoring(const csrgraph& graph, const vector<int>& color);

#endif
