#include "coloring.h"
#include <algorithm>   // sort() ke liye

/* ============================================================================
   GREEDY COLORING KI IDEA:
   1) Vertices ko ek order mein arrange karo (yahan: DEGREE ke hisaab se
      BADE-SE-CHHOTE, taaki "sabse zyada connections wale" vertices PEHLE
      color ho — ye ek achha heuristic hai jo aksar KAM colors use karta hai)
   2) Har vertex ko is order mein lo, aur usko SABSE CHHOTA color-number (0,1,2...)
      do jo uske KISI BHI already-colored neighbour ke color se MATCH na kare.

   ============================================================================
   DRY RUN EXAMPLE (color_10.txt, 10 vertices, HAR vertex ka degree=4 —
   "circulant" graph: i jud'a hai i-2,i-1,i+1,i+2 se, mod 10):
        0: [1,2,8,9]   1: [0,2,3,9]   2: [0,1,3,4]   3: [1,2,4,5]   4: [2,3,5,6]
        5: [3,4,6,7]   6: [4,5,7,8]   7: [5,6,8,9]   8: [0,6,7,9]   9: [0,1,7,8]

   Kyunki SAB vertices ka degree SAME (4) hai, sort ke baad order WAISA HI
   rehta hai (0,1,2,...,9) — tie-breaker "a < b" activate hota hai.

   x=0 (u=0): koi neighbour colored nahi -> c=0 milta hai         color[0]=0
   x=1 (u=1): neighbour 0 ka color=0 (conflict at c=0) -> c=1     color[1]=1
   x=2 (u=2): neighbours 0(c=0),1(c=1) dono conflict -> c=2       color[2]=2
   x=3 (u=3): neighbours 1(c=1),2(c=2); c=0 FREE hai (koi neighbour c=0 nahi)  color[3]=0
   x=4 (u=4): neighbours 2(c=2),3(c=0); c=1 FREE                  color[4]=1
   x=5 (u=5): neighbours 3(c=0),4(c=1); c=2 FREE                  color[5]=2
   x=6 (u=6): neighbours 4(c=1),5(c=2); c=0 FREE                  color[6]=0
   x=7 (u=7): neighbours 5(c=2),6(c=0); c=1 FREE                  color[7]=1
   x=8 (u=8): neighbours 0(c=0),6(c=0),7(c=1); c=2 FREE           color[8]=2
   x=9 (u=9): neighbours 0(c=0),1(c=1),7(c=1),8(c=2); SAB teen colors
              (0,1,2) BLOCK ho gaye -> c=3 lena PADA (NAYA color!)  color[9]=3

   FINAL: color[] = [0,1,2,0,1,2,0,1,2,3]   colorsUsed = 4
   (Maine khud compile+run karke verify kiya, EXACT yehi output aaya.)
   ============================================================================ */

vector<int> greedyColoring(const csrgraph& graph, int& colorsUsed)
{
    int n = graph.rowPtr.size() - 1;       // total vertices
    vector<int> color(n, -1);               // -1 matlab "abhi tak koi color nahi mila"
    vector<int> order(n);                    // vertices ko KIS ORDER mein color karna hai, ye batayega

    for (int i = 0; i < n; i++)
        order[i] = i;
    // start mein natural order: 0,1,2,...,n-1

    sort(order.begin(), order.end(), [&](int a, int b)
    {
        // ye ek LAMBDA (anonymous inline function) hai, sort() ka comparator
        int da = graph.rowPtr[a + 1] - graph.rowPtr[a];   // vertex a ka DEGREE (kitne neighbours hai)
        int db = graph.rowPtr[b + 1] - graph.rowPtr[b];   // vertex b ka DEGREE

        if (da != db)
            return da > db;    // BADA degree wala vertex PEHLE aana chahiye
        return a < b;           // agar degree SAME hai to chhota-number wala pehle (stable tie-break)
    });
    // is sorting ke baad "order[]" mein vertices HIGH-DEGREE-FIRST order mein hai
    // (jo greedy-coloring ke liye ek classic heuristic hai — jyada-connected
    // vertices ko pehle color karna, kyunki unko color-clash hone ka risk zyada hota hai)

    for (int x = 0; x < n; x++)     // order[] ke hisaab se ek-ek vertex process karo
    {
        int u = order[x];                     // is step ka actual vertex
        int start = graph.rowPtr[u];           // u ke neighbours ka CSR range
        int end = graph.rowPtr[u + 1];

        int c = 0;              // sabse CHHOTE color (0) se try karna shuru karo
        bool used = true;        // loop mein pehli baar enter karne ke liye "true" set kiya

        while (used)
        {
            used = false;

            for (int i = start; i < end; i++)     // u ke SAARE neighbours check karo
            {
                int v = graph.colIdx[i];
                if (color[v] == c)
                    // agar koi neighbour PEHLE SE hi color 'c' le chuka hai,
                    // to hum color 'c' u ko NAHI de sakte (conflict hoga)
                {
                    used = true;
                    break;   // ek hi conflicting neighbour dhoondna kaafi hai, aage check mat karo
                }
            }

            if (used)
                c++;    // color 'c' BLOCKED hai -> agla color try karo (c+1)
        }
        // is while-loop ka RESULT: 'c' ab wo SABSE CHHOTA color hai jo KISI
        // bhi neighbour se CLASH nahi karta

        color[u] = c;                              // u ko final color de do
        if (c + 1 > colorsUsed)
            colorsUsed = c + 1;
            // colorsUsed track karta hai ki AB TAK ka SABSE BADA color-number+1
            // kya hai (matlab total DISTINCT colors kitne use hue — 0-indexed hai
            // isliye "+1" karna zaroori hai count nikalne ke liye)
    }

    return color;   // DRY RUN: [0,1,2,0,1,2,0,1,2,3]
}

bool checkColoring(const csrgraph& graph, const vector<int>& color)
{
    // ye SIRF verification/testing function hai — coloring VALID hai ya nahi check karta
    int n = graph.rowPtr.size() - 1;

    for (int u = 0; u < n; u++)
    {
        for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++)
        {
            int v = graph.colIdx[i];
            if (color[u] == color[v])
                return false;   // agar KISI bhi edge (u,v) ke dono ends ka color SAME mila -> INVALID
        }
    }

    return true;   // sab edges check ho gayi, kahin bhi clash nahi mila -> VALID coloring hai
}
