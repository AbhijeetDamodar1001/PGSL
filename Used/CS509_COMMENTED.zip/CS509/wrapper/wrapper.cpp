#include <iostream>
#include <cstdlib>     // system() function ke liye chahiye (OS-level command chalane ke liye)
// ⚠️ NOTE: <string> header YAHAN INCLUDE NAHI kiya gaya, jabki "string" type
// (jaise "string file = ...") neeche use ho raha hai! Ye is waqt COMPILE ho
// jaata hai kyunki <iostream> practically hamesha <string> ko INDIRECTLY
// include kar deta hai (GCC/libstdc++ mein), lekin ye GUARANTEED BEHAVIOUR
// NAHI hai (standard ke hisaab se) — kisi doosre compiler par FAIL ho sakta
// hai. IMPROVEMENT: `#include <string>` explicitly add karna chahiye.

using namespace std;

/* ============================================================================
   YE FILE KYA HAI:
   Ek "MENU-DRIVEN LAUNCHER" hai — user se poochta hai "kaunsa assignment
   chalana hai", fir "kaunsa part", fir "kaunsa test-case file", aur phir
   `system()` calls ke through us assignment ki apni driver.cpp ko COMPILE
   (g++ se) aur RUN karta hai — jaise ek chhota "menu wrapper".

   ⚠️ WINDOWS-ONLY DESIGN: Har system() call mein "cd /d ..\\assignment_XX"
   jaisa DOS/Windows command hai ("/d" flag aur "\\" backslash paths sirf
   Windows ke cmd.exe mein chalte hai). Linux/Mac par ye seedhe FAIL ho
   jaayega. Cross-platform banane ke liye ideally #ifdef _WIN32 / #else
   (jaisa poore CS509 assignment_01 lab wale project mein processor.c ne
   kiya tha) use karna chahiye, ya phir CMake/Makefile jaisa build-system
   use karna chahiye (poore CS509 project mein KAHI bhi Makefile nahi hai —
   sirf ye wrapper.cpp hi "build system" ka kaam kar raha hai).
   ============================================================================ */

int main()
{
    int assignment;

    // ---------- Top-level menu: kaunsa assignment chalana hai ----------
    cout << "1. Assignment 1" << endl;
    cout << "2. Assignment 2" << endl;
    cout << "3. Assignment 3" << endl;
    cout << "4. Assignment 4" << endl;
    cout << "Enter choice: ";
    cin >> assignment;
    // NOTE: yaha bhi (jaise poore file mein) `cin >> assignment` ka return-value
    // CHECK nahi ho raha — agar user koi NUMBER ki jagah TEXT type kare
    // (jaise "one"), to cin FAIL ho jayega aur "assignment" ki value
    // UNPREDICTABLE (aksar 0, purani value rehti hai) — is se program
    // silently "Invalid assignment choice" chala jaata hai, crash nahi hota,
    // lekin behaviour thoda CONFUSING ho sakta hai (IMPROVEMENT POINT).

    // ================================================================
    // ASSIGNMENT 1: GEMM ya CSR
    // ================================================================
    if (assignment == 1)
    {
        int part;

        cout << "\nAssignment 1" << endl;
        cout << "1. GEMM" << endl;
        cout << "2. CSR" << endl;
        cout << "Enter choice: ";
        cin >> part;

        if (part == 1)      // ---------- GEMM chuna gaya ----------
        {
            string tests[] = {
                "test_01.txt",
                "test_02.txt",
                "test_03.txt"
            };
            // GEMM ke 3 available test-files (assignment_01/GEMM/tests/ ke andar wale)

            cout << "\nGEMM Test Cases" << endl;
            for (int i = 0; i < 3; i++)
                cout << i + 1 << ". " << tests[i] << endl;
                // user ko numbered list dikhao: "1. test_01.txt" ... "3. test_03.txt"

            cout << "Enter test case: ";

            int test;
            cin >> test;

            if (test < 1 || test > 3)
                // sirf 1,2,3 hi valid hai — koi bhi aur number (0, 4, -5, etc.) reject
            {
                cout << "Invalid test case." << endl;
                return 0;
            }

            string file = tests[test - 1];
            // "test-1" isliye kyunki array 0-indexed hai lekin user ko 1-indexed dikhaya (1,2,3)

            system(
                "cd /d ..\\assignment_01\\GEMM && "
                "g++ -std=c++17 driver\\driver.cpp "
                "src\\simple.cpp src\\blocking.cpp -o gemm.exe"
            );
            // ⚡ YE ASLI COMPILE COMMAND HAI: "cd /d" se wrapper folder se
            // assignment_01/GEMM folder mein jaate hai, fir g++ se
            // driver.cpp+simple.cpp+blocking.cpp ko jodkar "gemm.exe" banate hai.
            // NOTE: is `system()` call ka RETURN VALUE yaha CHECK NAHI ho raha
            // (Assignment 2/3/4 ke blocks mein `int result = system(...)` karke
            //  check hota hai, lekin Assignment 1 (GEMM/CSR) mein NAHI —
            //  ye ek INCONSISTENCY hai poore file mein — IMPROVEMENT POINT.
            //  Agar compile FAIL ho jaaye, to niche wala "gemm.exe" chalane
            //  wala command bhi silently fail ho jayega, bina clear error ke.)

            cout << "\nRunning: " << file << endl;

            string command =
                "cd /d ..\\assignment_01\\GEMM && "
                "gemm.exe tests\\" + file;
                // "gemm.exe tests\test_01.txt" jaisa final command banaya

            system(command.c_str());
            // ab poori tarah bana hua EXE run karo test-file ke saath
        }

        else if (part == 2)      // ---------- CSR chuna gaya ----------
        {
            string tests[] = {
                "graph_1.txt",
                "graph_2.txt"
            };

            cout << "\nCSR Test Cases" << endl;
            for (int i = 0; i < 2; i++)
                cout << i + 1 << ". " << tests[i] << endl;

            cout << "Enter test case: ";

            int test;
            cin >> test;

            if (test < 1 || test > 2)
            {
                cout << "Invalid test case." << endl;
                return 0;
            }

            string file = tests[test - 1];

            system(
                "cd /d ..\\assignment_01\\CSR && "
                "g++ -std=c++17 driver\\driver.cpp src\\csr.cpp -o csr.exe"
            );
            // CSR driver.cpp + csr.cpp compile karke "csr.exe" banaya

            cout << "\nRunning: " << file << endl;

            string command =
                "cd /d ..\\assignment_01\\CSR && "
                "csr.exe tests\\" + file;

            system(command.c_str());
            // ⚠️ REMINDER: agar user "graph_1.txt" chunta hai, to yaad rakhna
            // ki wo test-file KHUD CORRUPTED hai (csr.cpp comments mein detail
            // hai) — output GARBAGE aayega, ye wrapper ka bug nahi, TEST-DATA
            // ka bug hai.
        }
    }

    // ================================================================
    // ASSIGNMENT 2: Bellman-Ford ya Floyd-Warshall
    // ================================================================
    else if (assignment == 2)
    {
        int part;

        cout << "\nAssignment 2" << endl;
        cout << "1. Bellman-Ford" << endl;
        cout << "2. Floyd-Warshall" << endl;
        cout << "Enter choice: ";
        cin >> part;

        string algorithm;    // driver.cpp ko "bf" ya "fw" pass karna hoga
        string tests[5];      // dono ke paas 5-5 test files hai

        if (part == 1)
        {
            algorithm = "bf";
            tests[0] = "bf_10.txt";
            tests[1] = "bf_100.txt";
            tests[2] = "bf_10000.txt";
            tests[3] = "bf_50000.txt";
            tests[4] = "bf_100000.txt";

            cout << "\nBellman-Ford Test Cases" << endl;
        }
        else if (part == 2)
        {
            algorithm = "fw";
            tests[0] = "fw_10.txt";
            tests[1] = "fw_100.txt";
            tests[2] = "fw_500.txt";
            tests[3] = "fw_1000.txt";
            tests[4] = "fw_2000.txt";

            cout << "\nFloyd-Warshall Test Cases" << endl;
        }
        else
        {
            cout << "Invalid choice." << endl;
            return 0;
        }

        for (int i = 0; i < 5; i++)
            cout << i + 1 << ". " << tests[i] << endl;

        cout << "Enter test case: ";

        int test;
        cin >> test;

        if (test < 1 || test > 5)
        {
            cout << "Invalid test case." << endl;
            return 0;
        }

        string file = tests[test - 1];

        int result = system(
            "cd /d ..\\assignment_02 && "
            "g++ -std=c++17 driver\\driver.cpp "
            "src\\bellmanford.cpp src\\floydwarshall.cpp "
            "../assignment_01/CSR/src/csr.cpp "
            "-I../assignment_01/CSR/src -o assignment.exe"
        );
        // YAHAN result CAPTURE ho raha hai (Assignment 1 se DIFFERENT/BEHTAR):
        // g++ compile karta hai driver+bellmanford+floydwarshall+CSR module ko
        // ek saath, "-I../assignment_01/CSR/src" se compiler ko batata hai ki
        // "csr.h" header wahan dhoondo bhi (include path)

        if (result != 0)
            // system() ka return code non-zero hai matlab COMPILE FAIL hua
        {
            cout << "Compilation failed." << endl;
            return 0;   // exe chalane ki koshish hi mat karo (Assignment1 mein ye check missing tha!)
        }

        cout << "\nRunning: " << file << endl;

        string command =
            "cd /d ..\\assignment_02 && "
            "assignment.exe " + algorithm + " tests\\" + file;
            // jaise: "assignment.exe bf tests\bf_10.txt"

        system(command.c_str());
    }

    // ================================================================
    // ASSIGNMENT 3: Kruskal ya Prim (upar wale JAISA HI pattern hai)
    // ================================================================
    else if (assignment == 3)
    {
        int part;

        cout << "\nAssignment 3" << endl;
        cout << "1. Kruskal" << endl;
        cout << "2. Prim" << endl;
        cout << "Enter choice: ";
        cin >> part;

        string algorithm;

        if (part == 1)
            algorithm = "kruskal";
        else if (part == 2)
            algorithm = "prim";
        else
        {
            cout << "Invalid choice." << endl;
            return 0;
        }
        // NOTE: yaha (Assignment2 se DIFFERENT) test-files ki list Kruskal/Prim
        // dono ke liye SAME hai (dono SAME graph par chalte hai), isliye
        // "tests[5]" sirf EK BAAR define hoti hai, part-choice ke bahar:

        string tests[] = {
            "mst_10.txt",
            "mst_100.txt",
            "mst_10000.txt",
            "mst_50000.txt",
            "mst_100000.txt"
        };

        cout << "\nTest Cases" << endl;
        for (int i = 0; i < 5; i++)
            cout << i + 1 << ". " << tests[i] << endl;

        cout << "Enter test case: ";

        int test;
        cin >> test;

        if (test < 1 || test > 5)
        {
            cout << "Invalid test case." << endl;
            return 0;
        }

        string file = tests[test - 1];

        int result = system(
            "cd /d ..\\assignment_03 && "
            "g++ -std=c++17 driver\\driver.cpp "
            "src\\kruskal.cpp src\\prim.cpp "
            "../assignment_01/CSR/src/csr.cpp "
            "-I../assignment_01/CSR/src -o assignment.exe"
        );
        // kruskal.cpp AUR prim.cpp DONO EK SAATH compile ho rahe hai (chahe
        // user ne sirf "kruskal" chuna ho) — thoda WASTEFUL hai (dono baar
        // compile hote hai chahe ek hi run ho raha ho), lekin functionally
        // sahi hai kyunki dono chhote files hai (compile-time negligible)

        if (result != 0)
        {
            cout << "Compilation failed." << endl;
            return 0;
        }

        cout << "\nRunning: " << file << endl;

        string command =
            "cd /d ..\\assignment_03 && "
            "assignment.exe " + algorithm + " tests\\" + file;

        system(command.c_str());
    }

    // ================================================================
    // ASSIGNMENT 4: Coloring ya PageRank (upar wale jaisa hi pattern)
    // ================================================================
    else if (assignment == 4)
    {
        int part;

        cout << "\nAssignment 4" << endl;
        cout << "1. Coloring" << endl;
        cout << "2. PageRank" << endl;
        cout << "Enter choice: ";
        cin >> part;

        string algorithm;
        string tests[5];

        if (part == 1)
        {
            algorithm = "color";

            tests[0] = "color_10.txt";
            tests[1] = "color_100.txt";
            tests[2] = "color_10000.txt";
            tests[3] = "color_50000.txt";
            tests[4] = "color_100000.txt";

            cout << "\nColoring Test Cases" << endl;
        }
        else if (part == 2)
        {
            algorithm = "pagerank";

            tests[0] = "pagerank_10.txt";
            tests[1] = "pagerank_100.txt";
            tests[2] = "pagerank_1000.txt";
            tests[3] = "pagerank_10000.txt";
            tests[4] = "pagerank_50000.txt";

            cout << "\nPageRank Test Cases" << endl;
        }
        else
        {
            cout << "Invalid choice." << endl;
            return 0;
        }

        for (int i = 0; i < 5; i++)
            cout << i + 1 << ". " << tests[i] << endl;

        cout << "Enter test case: ";

        int test;
        cin >> test;

        if (test < 1 || test > 5)
        {
            cout << "Invalid test case." << endl;
            return 0;
        }

        string file = tests[test - 1];

        int result = system(
            "cd /d ..\\assignment_04 && "
            "g++ -std=c++17 driver\\driver.cpp "
            "src\\coloring.cpp src\\pagerank.cpp "
            "../assignment_01/CSR/src/csr.cpp "
            "-Isrc -I../assignment_01/CSR/src "
            "-o assignment4.exe"
        );
        // yaha DO include-paths hai: "-Isrc" (assignment_04/src/csr.h wrapper
        // ke liye) AUR "-I../assignment_01/CSR/src" (asli csr.h ke liye)

        if (result != 0)
        {
            cout << "Compilation failed." << endl;
            return 0;
        }

        cout << "\nRunning: " << file << endl;

        string command =
            "cd /d ..\\assignment_04 && "
            "assignment4.exe " + algorithm + " tests\\" + file;

        system(command.c_str());
    }

    else
        // assignment number 1,2,3,4 ke alawa kuch aur (jaise 5, 0, -1) type kiya gaya
    {
        cout << "Invalid assignment choice." << endl;
    }

    return 0;
}

/* ============================================================================
   SUMMARY / IMPROVEMENTS (is puri wrapper.cpp file ke liye):

   1. WINDOWS-ONLY: "cd /d" aur backslash paths sirf Windows par chalte hai.
      Cross-platform banane ke liye #ifdef _WIN32 use karo (jaisa CS509 ka
      pehla OS-simulator lab already karta tha).

   2. system() return-value INCONSISTENTLY check ho raha hai:
      Assignment 1 (GEMM/CSR) mein bilkul check nahi hota, Assignment 2/3/4
      mein hota hai. Sab jagah same pattern (`if(result!=0) {...}`) hona chahiye.

   3. Missing `#include <string>` — abhi "accidentally" compile ho raha hai
      kyunki <iostream> usually <string> ko transitively include kar deta hai.

   4. `cin >> assignment` / `cin >> part` / `cin >> test` — koi bhi INVALID
      (non-numeric) input handle nahi hoti gracefully, sirf silently "Invalid
      choice" print ho jaata hai (kabhi-kabhi confusing bhi ho sakta hai agar
      cin FAIL state mein chala jaaye).

   5. Har baar POORA project RECOMPILE hota hai (chahe pehle se .exe bana ho),
      isse test-run har baar THODA slow hota hai. Ek "already compiled hai kya"
      check (jaise Makefile ka dependency-tracking) add kar sakte the.

   6. Test-case file-names HARDCODED hai (agar tests/ folder mein NAYI file
      add ho jaaye jaisi "bf_500.txt", to wrapper.cpp mein bhi MANUALLY add
      karni padegi). Better: directory-listing se dynamically test-files
      dhoondh lo (ya command-line argument se filename accept karo).
   ============================================================================ */
