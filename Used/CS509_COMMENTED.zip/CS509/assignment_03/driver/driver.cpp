#include <iostream>
#include <fstream>
#include <vector>
#include <utility>      // pair<> ke liye
#include <chrono>       // time measurement ke liye

#include "../../assignment_01/CSR/src/csr.h"
#include "../src/kruskal.h"
#include "../src/prim.h"

using namespace std;
using namespace chrono;

/* ============================================================================
   Usage:  ./driver kruskal  mst_10.txt
           ./driver prim     mst_10.txt
   Dono commands SAME graph-file padhte hai, bas alag ALGORITHM chalate hai.
   ============================================================================ */

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        cout << "Algorithm or test file not given." << endl;
        return 1;
    }

    string choice = argv[1];      // "kruskal" ya "prim"
    string testFile = argv[2];    // jaise "mst_10.txt"

    ifstream input(testFile);

    if (!input)
    {
        cout << "Could not open MST input file." << endl;
        return 1;
    }

    int vertices, edges;
    input >> vertices >> edges;
    // DRY RUN (mst_10.txt): vertices=10, edges=24 (undirected graph, isliye har
    // edge DO baar file mein listed hai — ek "u ke row" mein, ek "v ke row" mein)

    vector<vector<pair<int, int>>> graph(vertices);

    for (int i = 0; i < vertices; i++)      // har vertex ki adjacency-line padho
    {
        int vertex, degree;
        input >> vertex >> degree;

        for (int j = 0; j < degree; j++)
        {
            int next, weight;
            input >> next >> weight;
            graph[vertex].push_back({next, weight});
        }
    }
    // DRY RUN: graph[0] = [{1,1},{2,10},{3,11}]  (mst_10.txt ki pehli line se)

    input.close();

    csrgraph csr = convert_to_csr(graph);
    // adjacency-list ko CSR mein convert kiya (assignment_01 module reuse)

    if (choice == "kruskal")
    {
        vector<MSTEdge> mstEdges;    // yahan Kruskal ki chuni hui edges aayengi

        auto start = high_resolution_clock::now();

        int totalWeight = kruskalMST(csr, mstEdges);

        auto stop = high_resolution_clock::now();

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nKruskal MST" << endl;

        for (const auto& e : mstEdges)
            cout << e.from << " " << e.to << " " << e.weight << endl;

        cout << "Total MST weight: " << totalWeight << endl;
        // DRY RUN OUTPUT (maine khud verify kiya): 9 edges, sab weight=1,
        // "Total MST weight: 9"

        cout << "Execution time: "
             << timeTaken.count() / 1000.0
             << " ms" << endl;
             // NOTE: yahan microseconds ko /1000.0 karke milliseconds mein
             // convert kiya ja raha hai (kyunki bellmanford/fw driver mein
             // seedha microseconds print hota tha, yahan ms mein — DIFFERENT
             // UNITS use ho rahe hai alag-alag drivers mein, ye inconsistency hai)
    }
    else if (choice == "prim")
    {
        vector<MSTEdge> mstEdges;    // yahan Prim ki chuni hui edges aayengi

        auto start = high_resolution_clock::now();

        int totalWeight = primMST(csr, mstEdges);

        auto stop = high_resolution_clock::now();

        auto timeTaken =
            duration_cast<microseconds>(stop - start);

        cout << "\nPrim MST" << endl;

        for (const auto& e : mstEdges)
            cout << e.from << " " << e.to << " " << e.weight << endl;

        cout << "Total MST weight: " << totalWeight << endl;
        // DRY RUN OUTPUT (maine khud verify kiya): "Total MST weight: 9"
        // (Kruskal ke SAME weight — dono algorithms SAHI hai, ye cross-check
        //  bhi hai ki dono implementations ek dusre se agree karte hai!)

        cout << "Execution time: "
             << timeTaken.count() / 1000.0
             << " ms" << endl;
    }
    else
    {
        cout << "Invalid algorithm." << endl;
        return 1;
    }

    return 0;
}
