#ifndef KRUSKAL_H
#define KRUSKAL_H

#include <vector>
#include "../../assignment_01/CSR/src/csr.h"   // CSR module yahan bhi reuse ho raha hai

using namespace std;

// Ek MST (Minimum Spanning Tree) ka edge represent karta hai
struct MSTEdge
{
    int from;      // edge ka ek end-point
    int to;        // edge ka doosra end-point
    int weight;    // us edge ka weight/cost
};

// Kruskal's Algorithm: Union-Find (Disjoint Set) use karke MST banata hai.
// graph: CSR format mein diya gaya UNDIRECTED weighted graph
// mst: OUTPUT parameter -> chuni gayi MST edges yahan bharega
// Return: MST ka total weight (sabhi chuni gayi edges ke weights ka sum)
int kruskalMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst
);

#endif
