#ifndef PRIM_H
#define PRIM_H

#include <vector>
#include "../../assignment_01/CSR/src/csr.h"
#include "kruskal.h"   // MSTEdge struct yahan se liya (Kruskal aur Prim SAME MSTEdge type use karte hai)

using namespace std;

// Prim's Algorithm: min-priority-queue (min-heap) use karke MST banata hai.
// Kruskal jaisa hi output deta hai (same MST weight), lekin ALAG approach se:
// Kruskal "edges" ko sort karta hai, Prim ek "growing tree" ko vertex-by-vertex badhata hai.
int primMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst
);

#endif
