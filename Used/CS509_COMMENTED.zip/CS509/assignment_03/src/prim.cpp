#include "prim.h"
#include <queue>        // priority_queue ke liye
#include <limits>       // numeric_limits<int>::max() ke liye ("infinity" represent karne)
#include <functional>   // greater<> comparator ke liye (min-heap banane ke liye)

/* ============================================================================
   PRIM'S ALGORITHM KI IDEA:
   Ek "tree" ko CHHOTE se badhate jaate hai — shuru mein sirf vertex-0 tree
   mein hai. Har step par, tree ke BAAHAR wale vertices mein se jo SABSE
   SASTA (min-weight) edge se tree se JUDTA hai, use tree mein SHAMIL kardo.
   Ye repeat karo jab tak SAARE vertices tree mein na aa jaaye.

   Min-heap (priority_queue) ka use isliye hota hai taaki "sabse sasta agla
   edge" TURANT (O(log V)) mil jaaye, bina baar-baar poora scan kiye.

   ============================================================================
   DRY RUN EXAMPLE (mst_10.txt, wahi chain-graph 0-1-2-...-9,
   adjacent-pair edges weight=1, "skip-1" edges weight=10, "skip-2" edges weight=11):

   START: best[]=[0,INF,INF,...], parent[]=[-1,-1,...], pq={(weight=0, vertex=0)}

   Step 1: pop (0,0) -> u=0. used[0]=1. (parent[0]=-1 hai isliye MST mein kuch add nahi hota,
           ye sirf "starting point" hai)
           neighbours of 0: 1(w1), 2(w10), 3(w11)
           -> best[1]=1,  push(1,1)
           -> best[2]=10, push(10,2)
           -> best[3]=11, push(11,3)

   Step 2: pop SABSE CHHOTA = (1,1) -> u=1. used[1]=1. parent[1]=0
           -> MST mein add: edge(0,1,weight=1)   totalWeight=1
           neighbours of 1: 2(w1) -> best[2] 10->1 (BEHTAR mila!) update, push(1,2)
                            3(w10)-> best[3] 11->10 update, push(10,3)
                            4(w11)-> best[4] update, push(11,4)

   Step 3: pop (1,2) -> u=2. used[2]=1. parent[2]=1
           -> MST add: edge(1,2,weight=1)   totalWeight=2
           (isi tarah aage 2 ke neighbours 3,4,5 ke "best[]" bhi update hote rahenge)

   ... isi pattern mein baar-baar "sabse chhota pending edge" (jo hamesha
   weight=1 wala hi milta hai kyunki wo already best[] mein update ho chuka
   hota hai) pop hota hai, aur pura CHAIN 0-1-2-...-9 ek-ek karke bante jaata hai.
   Beech mein pq mein purani "stale" entries (jaise (10,2) jo baad mein
   (1,2) se REPLACE ho gayi thi) bhi padi rehti hai, lekin jab wo pop hoti
   hai to "if(used[u]) continue;" unhe turant SKIP kar deta hai.

   FINAL MST (maine khud compile+run karke verify kiya):
       0-1(1), 1-2(1), 2-3(1), 3-4(1), 4-5(1), 5-6(1), 6-7(1), 7-8(1), 8-9(1)
   Total MST weight = 9   (Kruskal ke SAME answer — jo expected hai, kyunki
   MST WEIGHT हमेशा UNIQUE hota hai chahe algorithm koi bhi ho, agar sab
   weights distinct ho. Yaha kai edges ka weight SAME(1) hai, isliye
   EDGE-ORDER Kruskal se thoda alag ho sakta hai, lekin TOTAL WEIGHT same rahega.)
   ============================================================================ */

int primMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst
)
{
    int vertices = graph.rowPtr.size() - 1;

    if (vertices == 0)
        return 0;   // khaali graph -> koi MST nahi, weight 0

    vector<int> used(vertices, 0);
    // used[v]=1 matlab vertex v ALREADY tree mein shamil ho chuka hai

    vector<int> best(vertices, numeric_limits<int>::max());
    // best[v] = ab tak ka SABSE SASTA edge-weight jisse v tree se jud sakta hai
    // (INT_MAX matlab "abhi tak koi raasta nahi mila")

    vector<int> parent(vertices, -1);
    // parent[v] = tree mein v KIS vertex ke through jud raha hai (MST edge banane ke liye)

    priority_queue<
        pair<int, int>,          // {weight, vertex} pairs store honge
        vector<pair<int, int>>,
        greater<pair<int, int>>  // greater<> use karne se ye MIN-HEAP ban jaata hai
                                   // (default priority_queue MAX-heap hoti hai, isliye
                                   //  "greater" comparator dena zaroori hai taaki SABSE
                                   //  CHHOTA weight top() par aaye)
    > pq;

    best[0] = 0;         // vertex 0 se shuru karte hai (weight=0, "free" start)
    pq.push({0, 0});      // {weight=0, vertex=0} queue mein daalo

    int totalWeight = 0;

    while (!pq.empty())
    {
        int weight = pq.top().first;    // sabse chhoti pending edge ka weight
        int u = pq.top().second;         // ...aur uska vertex
        pq.pop();                          // use queue se nikaal do

        if (used[u])
            continue;
            // ⚡ LAZY DELETION: ye "stale" entry hai (jaise upar wala (10,2) jab
            // (1,2) already process ho chuki thi) — bas SKIP kardo, kuch mat karo.
            // (Ye better performance deta hai us approach se jisme queue ke
            //  andar jaake purani entry DHOOND KE nikaalni padti)

        used[u] = 1;   // ab u tree ka part ban gaya

        if (parent[u] != -1)
            // agar u ka koi parent hai (matlab u START vertex (0) nahi hai)
        {
            mst.push_back({parent[u], u, weight});
            // MST mein ye naya edge (parent[u] -> u) add kardo
            totalWeight += weight;
        }

        // u ke saare neighbours check karo — kya koi BEHTAR (sasta) raasta khulta hai?
        for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++)
        {
            int v = graph.colIdx[i];
            int w = graph.values[i];

            if (!used[v] && w < best[v])
                // agar v ABHI TAK tree mein nahi hai, AUR ye NAYA edge (u->v)
                // pehle se pata chale best[v] se SASTA hai
            {
                best[v] = w;         // best[] update kardo
                parent[v] = u;        // v ab u ke through hi tree mein aayega
                pq.push({w, v});       // is naye behtar option ko queue mein daalo
                // (purani entry queue mein hi padi rahegi, "stale" ban jaayegi,
                //  jo baad mein used[]-check se automatically discard ho jaayegi)
            }
        }
    }

    return totalWeight;   // DRY RUN: 9
}
