#include "kruskal.h"
#include <algorithm>   // sort() function ke liye chahiye

/* ============================================================================
   KRUSKAL'S ALGORITHM KI IDEA:
   1) Saari edges ko WEIGHT ke hisaab se CHHOTI-SE-BADI sort kardo.
   2) Sabse chhoti edge se shuru karke, ek-ek edge lo:
        - agar us edge ke dono end-points ALAG "group/set" mein hai
          (matlab unhe jodne se CYCLE nahi banegi) -> edge ko MST mein le lo,
          aur dono groups ko MERGE (union) kardo.
        - agar dono end-points PEHLE SE hi ek hi group mein hai
          (matlab jodne se cycle banegi) -> is edge ko REJECT kardo (skip).
   3) Jab (vertices-1) edges chun li jaaye, MST complete ho gaya (ruk jao).

   "Group/set" track karne ke liye UNION-FIND (Disjoint Set Union) data-structure
   use hoti hai — findParent() aur parent[]/rank[] arrays isi ke liye hai.
   ============================================================================
   DRY RUN EXAMPLE (mst_10.txt, 10 vertices — ek "chain" graph 0-1-2-...-9):
   Har adjacent pair (i, i+1) ke beech weight=1 ka edge hai (9 aisi edges),
   aur kuch "shortcut" edges bhi hai (i,i+2) weight=10, (i,i+3) weight=11 wagera.

   Sort karne ke baad SABSE PEHLE saari weight=1 wali edges aati hai:
      (0,1,1) (1,2,1) (2,3,1) (3,4,1) (4,5,1) (5,6,1) (6,7,1) (7,8,1) (8,9,1)
   -> ye poori 9 edges hai, aur 10 vertices ke MST ko exactly (10-1)=9 edges chahiye!

   Kyunki ye edges ek "chain" (0-1-2-...-9) banate hai, koi bhi do consecutive
   edge ek dusre se pehle se connected NAHI hoti (jab tak hum unhe add na kare),
   isliye HAR weight=1 edge accept ho jaati hai (koi cycle nahi banti), aur
   MST bilkul 9 edges tak pahunchte hi LOOP BREAK ho jaata hai — matlab
   weight=10 ya weight=11 wali edges ko KABHI CHECK hi nahi kiya jaata!

   FINAL MST (maine khud compile+run karke verify kiya, order thoda alag ho
   sakta hai kyunki std::sort "stable" nahi hai, lekin edges same hongi):
      4-5(1), 8-9(1), 7-8(1), 6-7(1), 5-6(1), 0-1(1), 3-4(1), 2-3(1), 1-2(1)
   Total MST weight = 9   (9 edges x weight 1 = 9)
   ============================================================================ */

int findParent(vector<int>& parent, int x)
{
    // UNION-FIND ka "FIND" operation (with PATH COMPRESSION optimization):
    // batata hai ki vertex x KIS "group/set" ka representative/root hai.
    if (parent[x] == x)
        return x;   // agar x khud apna parent hai, matlab x hi is group ka root/representative hai

    parent[x] = findParent(parent, parent[x]);
    // PATH COMPRESSION: recursively root dhoondo, aur RASTE MEIN AAYE saare
    // nodes ko SEEDHA root se jod do (taaki agli baar find() bahut FAST ho —
    // ye ek famous optimization hai jo Union-Find ko near-O(1) banati hai)
    return parent[x];
}

bool compareEdges(const MSTEdge& a, const MSTEdge& b)
{
    // sort() ke liye comparator: chhote weight wali edge pehle aani chahiye
    return a.weight < b.weight;
}

int kruskalMST(
    const csrgraph& graph,
    vector<MSTEdge>& mst
)
{
    int vertices = graph.rowPtr.size() - 1;
    // CSR mein rowPtr ka size hamesha (vertices+1) hota hai (dekh chuke ho csr.cpp mein)

    vector<MSTEdge> allEdges;   // poore graph ki SAARI (unique) edges yahan collect karenge

    for (int u = 0; u < vertices; u++)
    {
        for (int i = graph.rowPtr[u]; i < graph.rowPtr[u + 1]; i++)
        {
            int v = graph.colIdx[i];
            int w = graph.values[i];

            if (u < v)
                // ⚠️ IMPORTANT: graph UNDIRECTED hai, isliye CSR mein har edge
                // DO BAAR store hoti hai (ek baar u->v, ek baar v->u — dono
                // directions ki entry). "u < v" check se hum sirf EK BAAR
                // (kisi bhi ek direction mein) edge ko allEdges mein daalte hai,
                // duplicate se bachne ke liye. (Agar test-input GRAPH DIRECTED
                // ban jaaye kabhi, to ye assumption GALAT ho jayegi — improvement point)
                allEdges.push_back({u, v, w});
        }
    }
    // DRY RUN: allEdges mein total 12 unique edges aayengi (24 CSR-entries / 2, kyunki har edge do baar thi)

    sort(allEdges.begin(), allEdges.end(), compareEdges);
    // saari edges weight ke hisaab se ascending order mein sort kardi
    // DRY RUN: sabse pehle 9 weight=1 wali edges aayengi, fir weight=10 wali, fir weight=11 wali

    vector<int> parent(vertices);      // Union-Find: har vertex ka "parent" pointer
    vector<int> rank(vertices, 0);     // Union-Find: har group ki "height/rank" (balancing ke liye)

    for (int i = 0; i < vertices; i++)
        parent[i] = i;
        // START MEIN: har vertex apna khud ka parent hai (matlab har vertex apne-aap mein
        // ek ALAG group hai — abhi tak koi bhi do vertices connected nahi hai)

    int totalWeight = 0;

    for (int i = 0; i < allEdges.size(); i++)     // sorted order mein har edge try karo
    {
        int a = findParent(parent, allEdges[i].from);   // is edge ke 'from' vertex ka group-root
        int b = findParent(parent, allEdges[i].to);      // is edge ke 'to' vertex ka group-root

        if (a != b)
            // agar dono ALAG groups mein hai -> matlab is edge ko lene se CYCLE nahi banegi
        {
            mst.push_back(allEdges[i]);       // is edge ko MST mein SHAMIL kardo
            totalWeight += allEdges[i].weight;

            // ---------- UNION by RANK (chhote tree ko bade tree ke neeche jodna) ----------
            if (rank[a] < rank[b])
                parent[a] = b;      // a ka group chhota hai -> use b ke neeche jod do
            else if (rank[a] > rank[b])
                parent[b] = a;      // b ka group chhota hai -> use a ke neeche jod do
            else
            {
                parent[b] = a;      // dono same rank ke hai -> koi ek chuno (yahan a)
                rank[a]++;           // aur uska rank ek badha do (kyunki ab uski height badh gayi)
            }

            if (mst.size() == vertices - 1)
                // MST complete ho gaya (10 vertices ke liye 9 edges mil gayi)
                break;   // ⚡ EARLY EXIT: baaki (weight=10,11 wali) edges CHECK hi nahi hoti
        }
        // agar a==b (same group), to ye edge SKIP ho jaati hai (cycle banegi, isliye reject)
    }

    return totalWeight;   // DRY RUN: 9
}
