#include <iostream>
#include <fstream>       // file se matrix padhne ke liye (ifstream)
#include <vector>
#include <chrono>        // execution-time measure karne ke liye (high_resolution_clock)
#include <cstdlib>       // exit(), EXIT_FAILURE ke liye

#include "../src/simple.h"      // simpleMultiply() function
#include "../src/blocking.h"    // blockingMultiply() function

using namespace std;

void readMatrices(
    const string& fileName,
    vector<vector<int>>& matrixA,
    vector<vector<int>>& matrixB)
{
    // ---------- File format (test_01.txt jaisa): ----------
    //   pehli line: "rowsA colsA colsB"
    //   fir rowsA lines: matrixA ke rows (har ek mein colsA numbers)
    //   fir colsA lines: matrixB ke rows (har ek mein colsB numbers)
    ifstream inputFile(fileName);

    if (!inputFile.is_open())
    {
        cout << "Error: Unable to open input file." << endl;
        exit(EXIT_FAILURE);   // file na khule to turant program band kardo (error code 1 ke saath)
    }

    int rowsA, colsA, colsB;

    if (!(inputFile >> rowsA >> colsA >> colsB))
    {
        // >> operator agar fail ho jaaye (jaise file khaali ho ya numbers na ho)
        // to if(!(...)) true ho jaata hai
        cout << "Error: Invalid matrix dimensions." << endl;
        exit(EXIT_FAILURE);
    }
    // DRY RUN (test_01.txt): rowsA=2, colsA=3, colsB=2

    matrixA.resize(rowsA, vector<int>(colsA));   // matrixA ko 2x3 size mein resize karo (sab 0 se bhara)
    matrixB.resize(colsA, vector<int>(colsB));   // matrixB ko 3x2 size mein resize karo
    // NOTE: matrixB ki rows = colsA hoti hai (matrix-multiplication rule: A[m x n] * B[n x p])

    for (int i = 0; i < rowsA; i++)             // matrixA ki har row padho
    {
        for (int j = 0; j < colsA; j++)
        {
            if (!(inputFile >> matrixA[i][j]))
            {
                cout << "Error: Invalid data in Matrix A." << endl;
                exit(EXIT_FAILURE);
            }
        }
    }
    // DRY RUN: matrixA = [[1,2,3],[4,5,6]]

    for (int i = 0; i < colsA; i++)             // matrixB ki har row padho
    {
        for (int j = 0; j < colsB; j++)
        {
            if (!(inputFile >> matrixB[i][j]))
            {
                cout << "Error: Invalid data in Matrix B." << endl;
                exit(EXIT_FAILURE);
            }
        }
    }
    // DRY RUN: matrixB = [[7,8],[9,10],[11,12]]

    inputFile.close();   // file band karna zaroori hai
}

void printMatrix(const vector<vector<int>>& matrix, const string& title)
{
    // ek matrix ko terminal par heading ke saath print karta hai
    cout << "\n" << title << endl;

    for (const auto& row : matrix)     // har row par jao
    {
        for (int x : row)               // row ke har element ko
            cout << x << " ";            // space se separate karke print karo
        cout << endl;                     // row khatam hote hi naya line
    }
}

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        // program bina argument ke chalaya gaya (jaise sirf "./gemm" bina filename ke)
        cout << "Test file not given." << endl;
        return 1;
    }

    const int BLOCK_SIZE = 32;     // blocking-multiply ke liye tile-size HARDCODED hai
    // IMPROVEMENT: isko bhi command-line argument bana sakte the (jaise argv[2])
    // taaki alag-alag blockSize try karke performance compare kar sake bina recompile kiye

    string fileName = argv[1];      // pehla command-line argument = test-file ka naam
    // DRY RUN: agar "./gemm test_01.txt" chalaya to fileName = "test_01.txt"

    vector<vector<int>> matrixA;
    vector<vector<int>> matrixB;

    readMatrices(fileName, matrixA, matrixB);   // file se dono matrices padh lo

    // ---------- Simple (naive) multiply chalao aur time measure karo ----------
    auto startSimple = chrono::high_resolution_clock::now();   // stopwatch START
    vector<vector<int>> simpleResult =
        simpleMultiply(matrixA, matrixB);
    auto endSimple = chrono::high_resolution_clock::now();      // stopwatch STOP

    auto simpleTime =
        chrono::duration<double, milli>(endSimple - startSimple);
        // duration<double, milli> matlab result MILLISECONDS mein double ke roop mein chahiye

    printMatrix(simpleResult, "Simple GEMM Result");
    cout << "Execution Time : " << simpleTime.count() << " ms" << endl;
    // DRY RUN OUTPUT: "Simple GEMM Result \n 58 64 \n 139 154"

    // ---------- Blocking (tiled) multiply chalao aur time measure karo ----------
    auto startBlock = chrono::high_resolution_clock::now();
    vector<vector<int>> blockingResult =
        blockingMultiply(matrixA, matrixB, BLOCK_SIZE);
    auto endBlock = chrono::high_resolution_clock::now();

    auto blockingTime =
        chrono::duration<double, milli>(endBlock - startBlock);

    printMatrix(blockingResult, "Blocking GEMM Result");
    cout << "Execution Time : " << blockingTime.count() << " ms" << endl;
    // DRY RUN OUTPUT: "Blocking GEMM Result \n 58 64 \n 139 154"
    // (dono results SAME aane chahiye — ye ek achha "correctness check" hai:
    //  agar simple aur blocking ka answer mismatch ho to blocking mein
    //  koi indexing-bug hai)

    return 0;
}
