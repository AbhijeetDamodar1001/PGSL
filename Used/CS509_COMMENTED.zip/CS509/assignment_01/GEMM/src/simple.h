#ifndef SIMPLE_H
#define SIMPLE_H

#include <vector>

using namespace std;

// "Simple" (naive/textbook) tarike se do matrices multiply karne wala function.
// matrixA: rowsA x colsA size ki matrix
// matrixB: colsA x colsB size ki matrix (matrixA ke columns == matrixB ke rows hone chahiye)
// Return: rowsA x colsB size ki result matrix (A * B)
vector<vector<int>> simpleMultiply(
    const vector<vector<int>>& matrixA,
    const vector<vector<int>>& matrixB
);

#endif
