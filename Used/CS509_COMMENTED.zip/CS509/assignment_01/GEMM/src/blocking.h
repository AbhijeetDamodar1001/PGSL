#ifndef BLOCKING_H
#define BLOCKING_H

#include <vector>

using namespace std;

// "Blocking" (tiled) matrix multiplication -> cache-performance improve karne ke liye
// matrix ko chhote-chhote "blocks" (tiles) mein todkar multiply karta hai.
// blockSize: ek block ka size (jaise 32) — driver.cpp mein BLOCK_SIZE=32 hardcoded hai.
vector<vector<int>> blockingMultiply(
    const vector<vector<int>>& matrixA,
    const vector<vector<int>>& matrixB,
    int blockSize
);

#endif
