#include "simple.h"

/* ============================================================================
   DRY RUN EXAMPLE (test_01.txt se liya gaya chhota example):
   matrixA (2x3) = [ [1,2,3],
                     [4,5,6] ]
   matrixB (3x2) = [ [7, 8],
                     [9,10],
                     [11,12] ]

   Result[0][0] = 1*7 + 2*9 + 3*11 = 7+18+33 = 58
   Result[0][1] = 1*8 + 2*10+ 3*12 = 8+20+36 = 64
   Result[1][0] = 4*7 + 5*9 + 6*11 = 28+45+66 = 139
   Result[1][1] = 4*8 + 5*10+ 6*12 = 32+50+72 = 154

   Final Result (2x2) = [ [58, 64],
                          [139,154] ]
   (Actual compile+run se bhi yehi output aaya — neeche README mein full
    terminal output dekho.)
   ============================================================================ */

vector<vector<int>> simpleMultiply(
    const vector<vector<int>>& matrixA,
    const vector<vector<int>>& matrixB
)
{
    int rowsA = matrixA.size();       // matrixA mein kitni rows hai (example: 2)
    int colsA = matrixA[0].size();     // matrixA ki pehli row mein kitne columns hai (example: 3)
    int colsB = matrixB[0].size();     // matrixB ki pehli row mein kitne columns hai (example: 2)
    // NOTE: colsA == matrixB.size() (matrixB ki rows) honi chahiye, warna galat result ya
    // out-of-bounds crash ho sakta hai. Ye function KOI validation nahi karta (IMPROVEMENT POINT).

    // result matrix banao: rowsA x colsB size ki, sab 0 se initialize
    vector<vector<int>> resultMatrix(rowsA, vector<int>(colsB, 0));
    // example: resultMatrix = [[0,0],[0,0]]  (2x2, sab zero)

    // ---------- Teen nested loops = Naive/Textbook Matrix Multiplication (O(n^3)) ----------
    for (int i = 0; i < rowsA; i++)       // i = result ki row (0..rowsA-1)
{
    for (int k = 0; k < colsA; k++)        // k = "shared" dimension (matrixA ka column, matrixB ka row)
    {
        for (int j = 0; j < colsB; j++)     // j = result ki column (0..colsB-1)
        {
            // yehi standard formula hai: result[i][j] = sum over k of A[i][k]*B[k][j]
            resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
            // DRY RUN (i=0,k=0,j=0): resultMatrix[0][0] += A[0][0]*B[0][0] = 1*7 = 7
            // DRY RUN (i=0,k=1,j=0): resultMatrix[0][0] += A[0][1]*B[1][0] = 2*9 = 18 -> ab total 25
            // DRY RUN (i=0,k=2,j=0): resultMatrix[0][0] += A[0][2]*B[2][0] = 3*11= 33 -> ab total 58 (final)
            // isi tarah baaki cells bhi accumulate hoti hai
        }
    }
}
    // LOOP ORDER NOTE: ye i->k->j order use kar raha hai (na ki standard i->j->k).
    // Isse "row-major" memory access pattern better milta hai (matrixA[i][k] aur
    // matrixB[k][j] dono row-wise sequential padhe jaate hai), jo cache-friendly hai.
    // Ye chhota sa "cache-aware" optimization already yahan present hai, bina blocking ke.

    return resultMatrix;   // example return: [[58,64],[139,154]]
}
