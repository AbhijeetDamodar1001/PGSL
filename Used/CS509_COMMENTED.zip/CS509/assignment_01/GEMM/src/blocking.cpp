#include "blocking.h"
#include <algorithm>     // min() function ke liye chahiye

/* ============================================================================
   BLOCKING (TILED) MATRIX MULTIPLICATION KYA HAI, AUR KYU?
   -----------------------------------------------------------------
   simple.cpp wala naive multiply bhi mathematically bilkul sahi hai, lekin
   bade matrices (jaise 300x300, test_03.txt) ke liye CPU CACHE ka use kharab
   hota hai — kyunki matrixB[k][j] ko baar-baar alag-alag jagah se access
   karte hai jo cache mein fit nahi hota, isliye baar-baar cache-miss hota hai.

   BLOCKING/TILING iska solution hai: pura matrix ek saath process karne ki
   jagah, hum use chhote-chhote "blocks" (jaise 32x32 ke tiles) mein todte hai.
   Ek block itna chhota hota hai ki wo poora CPU cache mein fit ho jaaye,
   isliye jab tak ek block par kaam chal raha hai, cache-misses bahut kam
   ho jaate hai -> execution FASTER hota hai (result WAHI rehta hai).

   ============================================================================
   DRY RUN EXAMPLE #1 (chhota, samajhne ke liye): 4x4 identity-jaisi matrix,
   blockSize = 2. Bahar wale 3 loops (ii, kk, jj) blocks ke corners chunte hai:

     ii=0,kk=0,jj=0   ii=0,kk=0,jj=2   ii=0,kk=2,jj=0   ii=0,kk=2,jj=2
     ii=2,kk=0,jj=0   ii=2,kk=0,jj=2   ii=2,kk=2,jj=0   ii=2,kk=2,jj=2

   Total 8 blocks (2x2x2 grid) ban jaate hai kyunki 4/2=2 blocks har dimension mein.
   Har (ii,kk,jj) block ke andar phir chhote i,k,j loops chalte hai jo sirf
   us 2x2 chunk ke andar hi kaam karte hai (poore 4x4 matrix mein nahi).

   ============================================================================
   DRY RUN EXAMPLE #2 (assignment ke test_01.txt jaisa REAL case):
   matrixA (2x3), matrixB (3x2), BLOCK_SIZE = 32 (driver.cpp mein hardcoded)

   Kyunki rowsA=2, colsA=3, colsB=2 — ye sab already blockSize(32) se CHHOTE hai,
   isliye bahar wale loop (ii, kk, jj) sirf EK hi baar chalenge:
        ii=0 (rowLimit = min(0+32, 2) = 2)
        kk=0 (colLimitA = min(0+32, 3) = 3)
        jj=0 (colLimitB = min(0+32, 2) = 2)
   Matlab is chhote test-case ke liye blocking practically SIMPLE multiply jaisa
   hi behave karega (poora matrix hi "ek block" ban jaata hai) — isiliye
   dono (Simple aur Blocking) ka RESULT bilkul same aata hai:
        [[58, 64],
         [139,154]]
   (Maine khud compile+run karke confirm kiya — dono outputs match hue.)
   Blocking ka ASLI FAAYDA sirf BADE matrices (jaise test_03.txt, 300x300)
   par dikhega jaha multiple blocks banenge aur cache-hit-rate improve hoga.
   ============================================================================ */

vector<vector<int>> blockingMultiply(
    const vector<vector<int>>& matrixA,
    const vector<vector<int>>& matrixB,
    int blockSize
)
{
    int rowsA = matrixA.size();
    int colsA = matrixA[0].size();
    int colsB = matrixB[0].size();

    vector<vector<int>> resultMatrix(rowsA, vector<int>(colsB, 0));

    // ---------- Outer 3 loops: BLOCK-level iteration (ii, kk, jj "block corners") ----------
    for (int ii = 0; ii < rowsA; ii += blockSize)     // row-block ka starting index
    {
        for (int kk = 0; kk < colsA; kk += blockSize)   // shared-dimension block ka starting index
        {
            for (int jj = 0; jj < colsB; jj += blockSize)   // column-block ka starting index
            {
                // agar last block poora blockSize ka nahi bacha (matrix size blockSize
                // ka exact multiple nahi hai) to boundary ko clip karna zaroori hai,
                // warna out-of-bounds access ho jayega. min() isi ke liye hai.
                int rowLimit = min(ii + blockSize, rowsA);
                int colLimitA = min(kk + blockSize, colsA);
                int colLimitB = min(jj + blockSize, colsB);

                // ---------- Inner 3 loops: is ek block ke ANDAR "simple multiply" jaisa hi kaam ----------
                for (int i = ii; i < rowLimit; i++)
                {
                    for (int k = kk; k < colLimitA; k++)
                    {
                        for (int j = jj; j < colLimitB; j++)
                        {
                            // yehi formula hai jo simple.cpp mein bhi tha, bas is baar
                            // sirf CURRENT BLOCK ki range (ii..rowLimit, kk..colLimitA, jj..colLimitB) mein
                            resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
                        }
                    }
                }
            }
        }
    }

    return resultMatrix;
}

/* IMPROVEMENT / OBSERVATION:
   - Agar assignment ka goal blocking ka SPEEDUP measure karna hai, to
     driver.cpp ke test cases (2x3, 100x100, 300x300) chhote hai jabki
     BLOCK_SIZE=32 hai — isliye pehla test (test_01) mein blocking ka
     koi practical benefit nahi dikhega (upar dry-run mein dikhaya).
     Behtar comparison ke liye test_03.txt (300x300) use karo aur
     alag-alag blockSize (8, 16, 32, 64) try karke dekho kaunsa fastest hai
     — isse "cache blocking" concept better demonstrate hoga.
*/
