#include "csr.h"
// colIdx -> isme neighbour store honge
// values -> isme edges ke weight store honge
// rowPtr -> kisi vertex ke neighbors colIdx mein kahan se start aur kahan end hote hain

/* ============================================================================
   DRY RUN EXAMPLE (chhota, clean example — samajhne ke liye):

   adjacencyList (3 vertices):
     vertex 0 -> [(neighbour=1, weight=5), (neighbour=2, weight=3)]
     vertex 1 -> [(neighbour=2, weight=7)]
     vertex 2 -> [ ]   (koi outgoing edge nahi)

   Step by step trace:
   -----------------------------------------------------------
   START:  rowPtr = [0]                     (pehla 0 hamesha push hota hai)
           colIdx = [], values = []

   i=0 (vertex 0, 2 neighbours):
       j=0: colIdx.push(1), values.push(5)   -> colIdx=[1]      values=[5]
       j=1: colIdx.push(2), values.push(3)   -> colIdx=[1,2]    values=[5,3]
       rowPtr.push(colIdx.size()=2)          -> rowPtr=[0,2]

   i=1 (vertex 1, 1 neighbour):
       j=0: colIdx.push(2), values.push(7)   -> colIdx=[1,2,2]  values=[5,3,7]
       rowPtr.push(colIdx.size()=3)          -> rowPtr=[0,2,3]

   i=2 (vertex 2, 0 neighbours):
       (loop chalta hi nahi, kyunki adjacencyList[2] khaali hai)
       rowPtr.push(colIdx.size()=3)          -> rowPtr=[0,2,3,3]

   FINAL CSR:
       rowPtr = [0, 2, 3, 3]
       colIdx = [1, 2, 2]
       values = [5, 3, 7]

   ISKO PADHNE KA TARIKA: vertex v ke neighbours colIdx[rowPtr[v] .. rowPtr[v+1]-1]
   mein milenge. Example: vertex 0 ke neighbours = colIdx[rowPtr[0]..rowPtr[1]-1]
   = colIdx[0..1] = {1, 2}  (weights: values[0..1] = {5,3})  -- SAHI match hua!
   vertex 2 ke liye rowPtr[2]==rowPtr[3]==3, matlab colIdx[3..2] khaali range hai
   -> vertex 2 ka koi neighbour nahi (jo sahi hai, kyunki adjacencyList[2] khaali tha).
   ============================================================================ */
csrgraph convert_to_csr(const vector<vector<pair<int, int>>>& adjacencyList)
{
    csrgraph csr;

    csr.rowPtr.push_back(0);
    // rowPtr ka pehla element hamesha 0 hota hai (vertex 0 ke neighbours colIdx[0] se shuru honge)


    for (int i = 0; i < adjacencyList.size(); i++)// x vertex ke   -> i = current vertex number
    {
        for (int j = 0; j < adjacencyList[i].size(); j++) // jitne neighbour hai  -> vertex i ke sab neighbours par loop
        {
            csr.colIdx.push_back(adjacencyList[i][j].first);
            // adjacencyList[i][j].first = neighbour vertex-number, colIdx mein daal do
            csr.values.push_back(adjacencyList[i][j].second);
            // adjacencyList[i][j].second = us edge ka weight, values mein daal do (SAME index par)
        }

        csr.rowPtr.push_back(csr.colIdx.size());
        // vertex i ke saare neighbours daalne ke baad, colIdx ka current size hi
        // batata hai ki "vertex i+1 ke neighbours yahan se shuru honge"
        // (isliye rowPtr[i] se rowPtr[i+1] tak ka range vertex i ke neighbours hai)
    }

    return csr;
}

/* IMPORTANT REAL-WORLD BUG NOTED (tests/graph_1.txt mein):
   Jab maine driver.cpp ko compile karke assignment ke apne diye hue
   "graph_1.txt" test-file par chalaya, to output GALAT (garbage) aaya.
   Wajah: graph_1.txt mein har line "source degree dest weight" format follow
   karti hai, lekin us file ke andar KUCH lines mein degree ki value
   diye gaye (dest,weight) pairs ki actual GINTI se MATCH nahi karti
   (jaise "0 2 1 2" likha hai — degree=2 bola gaya lekin sirf EK hi
   (dest=1, weight=2) pair diya gaya hai, dusra pair missing hai).
   Isse driver.cpp ka parser "misaligned" ho jaata hai aur agli lines ke
   numbers galat jagah padh leta hai. graph_2.txt (jisme har vertex ka
   degree hamesha 1 hai, matching format) SAHI chalta hai.
   -> Submit karne se pehle graph_1.txt ko dobara check/fix karna chahiye.
*/
