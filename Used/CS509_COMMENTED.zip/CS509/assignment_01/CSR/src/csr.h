#ifndef CSR_H
#define CSR_H

#include <vector>

using namespace std;

// CSR = Compressed Sparse Row. Ye bade "sparse" graphs (jisme har vertex ke
// bahut kam neighbours hote hai) ko compactly store karne ka standard tarika hai.
// Poore adjacency-matrix (V x V, zyada memory) ki jagah sirf ACTUAL edges store
// hote hai (compact, memory-efficient, aur cache-friendly traversal).
struct csrgraph
{
    vector<int> rowPtr;    // rowPtr[v] se rowPtr[v+1] tak ka range batata hai ki
                             // vertex v ke neighbours colIdx[] mein KAHAN se KAHAN tak hai
    vector<int> colIdx;    // saare vertices ke saare neighbours (destination) ek line mein
    vector<int> values;    // colIdx[i] ke corresponding edge-weight yahan hai (same index)
};


//Mujhe adjacency list do, main usko CSR mein convert karke csrgraph return karunga.
csrgraph convert_to_csr(
    const vector<vector<pair<int, int>>>& adjacencyList
);
// adjacencyList[v] = list of {neighbour, weight} pairs jo vertex v se nikalte hai

#endif
