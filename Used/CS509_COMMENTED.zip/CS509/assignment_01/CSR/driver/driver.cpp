#include <iostream>
#include <fstream>
#include <vector>

#include "../src/csr.h"

using namespace std;

/* ============================================================================
   DRY RUN EXAMPLE (graph_2.txt ke pehle 3 vertices, jo achhi tarah formatted hai):
       File content (partial): "100 99 \n 0 1 1 1 \n 1 1 2 1 \n 2 1 3 1 ..."
       -> vertices=100, edges=99
       -> vertex 0: degree=1, ek edge (destination=1, weight=1)
       -> vertex 1: degree=1, ek edge (destination=2, weight=1)
       -> vertex 2: degree=1, ek edge (destination=3, weight=1)
       ... (ye ek "chain" graph hai: 0->1->2->3->...->99)

   Isse graph[0] = [{1,1}], graph[1] = [{2,1}], graph[2] = [{3,1}], ...
   convert_to_csr() ke through:
       rowPtr = [0,1,2,3,4,...,99,99]   (har vertex ka 1 hi neighbour, last vertex 99 ka 0)
       colIdx = [1,2,3,4,...,99]
       values = [1,1,1,1,...,1]
   (Maine ye khud compile+run karke verify kiya hai — README mein poora
    terminal-output diya hai.)
   ============================================================================ */

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        cout << "Test file not given." << endl;
        return 1;   // koi filename nahi diya gaya command-line par
    }

    string fileName = argv[1];        // pehla argument = test file ka naam (jaise "graph_2.txt")
    ifstream inputFile(fileName);

    if (!inputFile)
    {
        cout << "File could not be opened." << endl;
        return 1;
    }

    int vertices, edges;
    inputFile >> vertices >> edges;
    // DRY RUN: vertices=100, edges=99 (file ki pehli line se)
    // NOTE: yaha koi validation nahi hai ki >> fail hua ya nahi (agar file
    // corrupt ho to vertices/edges garbage/0 reh sakte hai — IMPROVEMENT POINT,
    // GEMM driver ki tarah yaha bhi `if(!(inputFile >> ...))` check hona chahiye)

    vector<vector<pair<int, int>>> graph(vertices);
    // adjacency-list banayi: 100 empty lists (ek har vertex ke liye)

    for (int i = 0; i < vertices; i++)      // har vertex ki line padho
    {
        int source, degree;
        inputFile >> source >> degree;
        // DRY RUN (i=0): source=0, degree=1

        for (int j = 0; j < degree; j++)     // us vertex ke "degree" number ke edges padho
        {
            int destination, weight;
            inputFile >> destination >> weight;
            // DRY RUN (i=0,j=0): destination=1, weight=1
            graph[source].push_back({destination, weight});
            // graph[0] = [{1,1}]
        }
    }
    // NOTE: yaha "source" file se hi padha ja raha hai (na ki loop-variable i se).
    // Normally source == i hona chahiye (agar file order mein hi vertices likhi hai),
    // lekin agar file mein order alag ho (jaise vertex numbers kisi bhi sequence mein
    // likhe ho) to bhi ye sahi se kaam karega, kyunki graph[source] use ho raha hai.

    inputFile.close();

    csrgraph csr = convert_to_csr(graph);
    // ab poori adjacency-list ko csr.cpp wale function se CSR format mein convert karo

    cout << "\nRow Pointer\n";
    for (int x : csr.rowPtr)
        cout << x << " ";
    // DRY RUN OUTPUT (pehle kuch values): "0 1 2 3 4 5 ..."

    cout << "\n\nColumn Index\n";
    for (int x : csr.colIdx)
        cout << x << " ";
    // DRY RUN OUTPUT: "1 2 3 4 5 ..."

    cout << "\n\nValues\n";
    for (int x : csr.values)
        cout << x << " ";
    // DRY RUN OUTPUT: "1 1 1 1 1 ..." (chain graph mein har edge ka weight 1 hai)

    cout << endl;

    return 0;
}
