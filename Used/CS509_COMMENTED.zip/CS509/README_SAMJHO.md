# CS509 — Parallel/Graph Algorithms Lab (Poora Samjho — Hinglish Guide)

Ye repo 4 chhote-chhote assignments ka collection hai — sab **graphs aur
matrices par classic algorithms** implement karte hai, aur ek common
**CSR (Compressed Sparse Row)** module baar-baar REUSE karte hai.

Maine har `.cpp`/`.h` file **khud compile aur RUN karke** dry-run examples
nikale hai (guesswork nahi) — har file ke andar comments mein "DRY RUN
EXAMPLE" section milega jisme ASLI numbers hai.

---

## 1. Padhne Ka SAHI ORDER

```
STEP 0: assignment_01/CSR/src/csr.h + csr.cpp
        -> Ye SABSE PEHLE samjho, kyunki baaki TEENO assignments
           (02, 03, 04) isी CSR module ko REUSE karte hai.

STEP 1: assignment_01/GEMM/  (simple.cpp -> blocking.cpp -> driver.cpp)
        -> Matrix multiplication, CSR se INDEPENDENT hai, standalone samajh sakte ho.

STEP 2: assignment_01/CSR/driver/driver.cpp
        -> Dekho adjacency-list file se CSR kaise banti hai (end-to-end)

STEP 3: assignment_02/  (bellmanford.cpp -> floydwarshall.cpp -> driver.cpp)
        -> Shortest path algorithms, CSR module reuse karte hai (bellmanford),
           floydwarshall CSR use NAHI karta (seedha matrix leta hai)

STEP 4: assignment_03/  (kruskal.cpp -> prim.cpp -> driver.cpp)
        -> MST algorithms, CSR reuse karte hai

STEP 5: assignment_04/  (csr.h wrapper -> coloring.cpp -> pagerank.cpp -> driver.cpp)
        -> Graph coloring aur PageRank, CSR reuse karte hai (via ek chhoti
           "wrapper" csr.h file jo asli csr.h ko re-include karti hai)

STEP 6: wrapper/wrapper.cpp
        -> SABSE AAKHIR mein — ye ek MENU hai jo upar ke saare assignments
           ko ek jagah se compile+run karne deta hai (Windows-only design)
```

**WHY is order?** CSR module "foundation" hai — baaki teen assignments (02,
03, 04) literally `#include "../../assignment_01/CSR/src/csr.h"` karte hai.
Isliye jab tak CSR structure (`rowPtr`/`colIdx`/`values`) samajh na aaye,
baaki files confusing lagengi.

---

## 2. CSR (Compressed Sparse Row) — Foundation Concept

```
Adjacency List:                 CSR Representation:
  vertex 0 -> [(1,5),(2,3)]       rowPtr = [0, 2, 3, 3]
  vertex 1 -> [(2,7)]              colIdx = [1, 2, 2]
  vertex 2 -> [ ]                   values = [5, 3, 7]

Padhne ka tarika: vertex v ke neighbours = colIdx[rowPtr[v] .. rowPtr[v+1]-1]
Example: vertex 0 -> colIdx[rowPtr[0]..rowPtr[1]-1] = colIdx[0..1] = {1,2}
         (weights: values[0..1] = {5,3})  ✅ match hota hai adjacency list se
```

Ye compact format bade **sparse** graphs (jisme har vertex ke kam neighbours
ho) ke liye memory-efficient hai, aur traversal bhi cache-friendly hota hai
(kyunki sab neighbours consecutively memory mein rakhe hote hai).

---

## 3. Har Assignment Ka Dry-Run Summary (maine khud compile+run kiya)

### Assignment 1a — GEMM (Matrix Multiplication)
`test_01.txt`: A(2x3)=[[1,2,3],[4,5,6]], B(3x2)=[[7,8],[9,10],[11,12]]
```
Simple GEMM Result       Blocking GEMM Result
58 64                    58 64
139 154                  139 154
```
Dono SAME answer dete hai (correctness cross-check). `blocking.cpp` mein
BLOCK_SIZE=32 hardcoded hai, jo is chhote test-case (2x3x2) se BADA hai —
isliye blocking practically "simple" jaisa hi behave karta hai. Iska ASLI
fayda `test_03.txt` (300x300) jaise BADE matrices par dikhega.

### Assignment 1b — CSR
`graph_2.txt` (100-vertex chain graph) SAHI chalta hai:
```
Row Pointer: 0 1 2 3 4 5 ... 99 99
Column Index: 1 2 3 4 5 ... 99
Values: 1 1 1 1 1 ... 1
```
⚠️ **BUG MILA**: `graph_1.txt` (5-vertex test) mein degree-count file ke
actual (dest,weight) pairs se **MATCH NAHI karta** — jaise "0 2 1 2" line
mein degree=2 bola gaya hai lekin sirf EK (dest=1,weight=2) pair diya gaya
hai. Isse driver ka parser MISALIGNED ho jaata hai aur GARBAGE CSR output
banta hai (maine khud compile+run karke confirm kiya). **Ye test-data ka
bug hai, code ka nahi** — submit karne se pehle `graph_1.txt` fix karna chahiye.

### Assignment 2a — Bellman-Ford
`bf_10.txt` (5 vertices, source=0):
```
Vertex Distance
0   0
1   2
2   4
3   7
4  -2
Negative cycle: none
```
⚠️ **DUSRA BUG MILA**: Original `bf_10.txt` file ke andar `//` INLINE
COMMENTS the (jaise "5 10 // 5 vertices..."). `ifstream >>` ye comments
STRIP NAHI karta — wo `//` ko bhi ek token maankar parse karne ki koshish
karta hai, jisse **poori file ka parsing MISALIGNED ho jaata hai** aur sab
distances galat/INF aa jaate hai! Maine comments hata kar (clean file
banakar) dobara test kiya to sahi answer mila (upar wala). **Test-data
files mein comments NAHI hone chahiye.**

### Assignment 2b — Floyd-Warshall
`fw_10.txt` (5x5 distance matrix, kuch cells "INF"):
```
 0   2   4   7  -2
-2   0   2   5  -4
-4  -2   0   3  -6
-7  -5  -3   0  -9
 2   4   6   9   0
```
Ye file SAHI (clean) hai, koi parsing issue nahi mila.

### Assignment 3 — Kruskal vs Prim (MST)
`mst_10.txt` (10-vertex "chain" graph, adjacent-edges weight=1):
```
Kruskal Total MST weight: 9        Prim Total MST weight: 9
```
Dono algorithms **SAME weight** dete hai (jo MST ka guaranteed property
hai) — ek achha CROSS-CHECK hai ki dono implementations sahi hai. Edge-order
thoda alag ho sakta hai (kyunki kai edges ka weight barabar hai), lekin
total weight hamesha same rahega.

### Assignment 4a — Greedy Vertex Coloring
`color_10.txt` (10-vertex "circulant" graph, har vertex degree=4):
```
Vertex colors: 0 1 2 0 1 2 0 1 2 3
Colors used: 4
Valid: true
```
Pattern `0,1,2,0,1,2,0,1,2` ban raha hai kyunki ye ek regular/symmetric
graph hai — lekin AAKHIRI vertex (9) ke pass itne saare already-colored
neighbours (0,1,7,8) hai ki usse ek NAYA (4th) color lena padta hai.

### Assignment 4b — PageRank
`pagerank_10.txt` (10-vertex regular directed graph, damping=0.85):
```
Sab vertices ka rank = 0.1
Sum of ranks: 1
Iterations: 1
Converged: true
```
Ye graph PERFECTLY REGULAR hai (har vertex ka in-degree=out-degree=2),
isliye PageRank **pehli hi iteration mein converge** ho jaata hai — kyunki
uniform starting-rank (0.1) already "steady state" hai. Real-world (asymmetric)
graphs mein normally isse ZYADA iterations lagti hai.

---

## 4. Improvements / Observations (poore project ke liye)

1. **Test-data files mein comments/typos hai** (`graph_1.txt` mein degree
   mismatch, original `bf_10.txt` mein `//` inline comments) jo actual
   PARSING todte hai — inhe fix karna chahiye submission se pehle.

2. **Input validation INCONSISTENT hai across drivers**: `assignment_04`
   ka driver sabse ZYADA defensive hai (har `>>` ke baad `if(!(...))`
   check karta hai), jabki GEMM/CSR/BF-FW/MST drivers mein bahut kam
   validation hai (agar file corrupt ho to silently galat output aata hai,
   crash nahi hota — jo debug karna MUSHKIL bana deta hai). Sabhi drivers
   mein assignment_04 wala pattern copy karna chahiye.

3. **`wrapper.cpp` Windows-only hai** (`cd /d`, backslash paths) — Linux/Mac
   par nahi chalega. `#ifdef _WIN32` se cross-platform banaya ja sakta hai.

4. **Poore project mein KOI Makefile/CMakeLists nahi hai** — sirf
   `wrapper.cpp` ke andar `system()` calls se g++ commands chalte hai. Ek
   proper Makefile (ya CMake) hona chahiye taaki har assignment
   independently, cross-platform compile ho sake bina wrapper.cpp ke.

5. **`system()` return-value check INCONSISTENT hai** `wrapper.cpp` mein —
   Assignment 1 (GEMM/CSR) mein check nahi hota, Assignment 2/3/4 mein hota
   hai. Sab jagah `if(result != 0) { ... }` pattern hona chahiye.

6. **Execution-time units INCONSISTENT hai**: kuch drivers `microseconds`
   print karte hai (BF/FW), kuch `milliseconds` (GEMM, Coloring/PageRank),
   aur MST driver microseconds ko manually `/1000.0` karke ms banata hai.
   Ek CONSISTENT unit (jaise hamesha microseconds) use karna chahiye taaki
   alag-alag assignments ke performance-numbers directly compare ho sake.

7. **`assignment_01/GEMM/driver/driver.cpp`** mein `BLOCK_SIZE=32`
   hardcoded hai — command-line argument bana dena chahiye taaki alag
   blockSize try karke "cache blocking" ka REAL speedup measure kiya ja sake.

8. **Kruskal mein `u < v` filter** (duplicate-edge removal) ye assume karta
   hai ki graph hamesha UNDIRECTED hai. Agar kabhi directed-graph test-case
   diya jaaye, to ye assumption todegi.

9. **CSR module mein `int` vs `size_t` sign-mismatch warnings** aati hai
   (`for(int i=0; i<adjacencyList.size(); i++)`) — `size_t`/`(int)` cast ya
   `size()` ko `int` mein convert karke warnings clean ki ja sakti hai.

---

## 5. Kaise Compile/Run Karein (Linux/Mac, WITHOUT wrapper.cpp)

```bash
# Assignment 1 - GEMM
g++ -std=c++17 -o gemm assignment_01/GEMM/driver/driver.cpp \
    assignment_01/GEMM/src/simple.cpp assignment_01/GEMM/src/blocking.cpp
./gemm assignment_01/GEMM/tests/test_01.txt

# Assignment 1 - CSR
g++ -std=c++17 -o csr assignment_01/CSR/driver/driver.cpp \
    assignment_01/CSR/src/csr.cpp
./csr assignment_01/CSR/tests/graph_2.txt

# Assignment 2 - Bellman-Ford / Floyd-Warshall
g++ -std=c++17 -o a2 assignment_02/driver/driver.cpp \
    assignment_02/src/bellmanford.cpp assignment_02/src/floydwarshall.cpp \
    assignment_01/CSR/src/csr.cpp
./a2 bf assignment_02/tests/bf_100.txt      # bf_10.txt corrupted hai, bf_100.txt use karo
./a2 fw assignment_02/tests/fw_10.txt

# Assignment 3 - Kruskal / Prim
g++ -std=c++17 -o a3 assignment_03/driver/driver.cpp \
    assignment_03/src/kruskal.cpp assignment_03/src/prim.cpp \
    assignment_01/CSR/src/csr.cpp
./a3 kruskal assignment_03/tests/mst_10.txt
./a3 prim assignment_03/tests/mst_10.txt

# Assignment 4 - Coloring / PageRank
g++ -std=c++17 -o a4 assignment_04/driver/driver.cpp \
    assignment_04/src/coloring.cpp assignment_04/src/pagerank.cpp \
    assignment_01/CSR/src/csr.cpp
./a4 color assignment_04/tests/color_10.txt
./a4 pagerank assignment_04/tests/pagerank_10.txt
```
(Maine ye SAB commands khud chalake dry-run outputs verify kiye hai.)

---

## 6. Quick Glossary

- **CSR** = Compressed Sparse Row — sparse graph ko compact `rowPtr/colIdx/values` mein store karna
- **Dry Run** = code ko haath se (ya compile karke) "trace" karna, step-by-step values dekhna
- **Union-Find (DSU)** = data-structure jo "kaun kis group mein hai" fast track karta hai (Kruskal mein use)
- **Min-Heap/Priority Queue** = hamesha "sabse chhoti value" turant deta hai (Prim mein use)
- **Damping Factor** = PageRank mein "link follow vs random jump" probability
- **Convergence** = jab algorithm ki values iteration-dar-iteration STABLE ho jaaye (badalna band ho jaaye)
